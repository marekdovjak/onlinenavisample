#import <Foundation/NSObject.h>
#import <CoreGraphics/CGBase.h>

@class SYMapMarker, NSArray;

/*!
 @brief Handles the display of a large number of SYMapMarkers.
 */
@interface SYMapMarkersCluster : NSObject

/*!
 @brief Cluster priority.
 Values from interval <0,1> are accepted. 0 is lowest priority and 1 is highest priority.
 Default value is 0.
 */
@property(nonatomic,assign) CGFloat priority;

/*!
 @brief Can be used to enable/disable overlapping of displayed SYMapMarkers with vehicle model.
 Default value is YES.
 */
@property(nonatomic,assign) BOOL detectVehicleCollision;

/*!
 @brief Returns all SYMapMarkers in cluster.
 */
@property(nonatomic,nullable,readonly) NSArray<SYMapMarker*>* mapMarkers;

/*!
 @brief Adds SYMapMarker to cluster.
 SYMapMarker must be added to SYMapView before adding to SYMapMarkersCluster!
 */
-(BOOL)addMapMarker:(nonnull SYMapMarker*)marker;

/*!
 @brief Removes SYMapMarker from SYMapMarkersCluster.
 */
-(BOOL)removeMapMarker:(nonnull SYMapMarker*)marker;
@end

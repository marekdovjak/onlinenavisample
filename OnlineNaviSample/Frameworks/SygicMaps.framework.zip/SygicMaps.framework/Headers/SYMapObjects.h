#import <CoreGraphics/CGBase.h>
#import <CoreGraphics/CGGeometry.h>
#import <UIKit/UIGeometry.h>
#import <SygicMaps/SYViewObjects.h>

@class SYGeoCoordinate, SYRoute, UIImage, UIColor;

/*!
 @brief Types of SYMapObject objects that an application can add to a map.
 */
typedef NS_ENUM(NSInteger, SYMapObjectType)
{
    SYMapObjectTypePoint,
    SYMapObjectTypeMarker,
    SYMapObjectTypeLabeledMarker,
    SYMapObjectTypePolygon,
    SYMapObjectTypePolyline,
    SYMapObjectTypeRoute,
    SYMapObjectTypeSafetySpot,
    SYMapObjectTypeContainer,
    SYMapObjectTypeCircle,
    SYMapObjectTypeRouteLabel,
    SYMapObjectTypeReserved
};

/*!
 @brief Route types which can be displayed on map using SYMapRoute.
 */
typedef NS_ENUM(NSInteger, SYMapRouteType)
{
    /*!
     @brief Primary calculated route.
     */
    SYMapRouteTypePrimary,
    
    /*!
     @brief Alternative to the primary calculated route.
     */
    SYMapRouteTypeAlternative,
    
    /*!
     @brief Custom calculated route.
     */
    SYMapRouteTypeCustom
};

/*!
 @brief SYMapObject's font style.
 */
typedef NS_ENUM(NSInteger, SYMapObjectFontStyle)
{
    SYMapObjectFontStyleRegular,
    SYMapObjectFontStyleBold,
    SYMapObjectFontStyleItalic
};

/*!
 @brief SYMapObject's text style.
 */
@interface SYMapObjectTextStyle : NSObject
-(nonnull instancetype)init;
-(nonnull instancetype)initWithFontSize:(CGFloat)fontSize fontStyle:(SYMapObjectFontStyle)fontStyle textColor:(nonnull UIColor*)textColor borderSize:(CGFloat)borderSize borderColor:(nullable UIColor*)borderColor;
@property (nonatomic,readonly) CGFloat fontSize;
@property (nonatomic,readonly) CGFloat borderSize;
@property (nonatomic,readonly) SYMapObjectFontStyle fontStyle;
@property (nonatomic,readonly,nonnull) UIColor* textColor;
@property (nonatomic,readonly,nullable) UIColor* borderColor;
@end

/*!
 @brief Base class for all view objects created by client application which can be added and shown on map.
 In order to display the object on the map, the object needs to be added to an SYMapView by calling addMapObject:.
 */
@interface SYMapObject : SYViewObject

/*!
 @brief An integer that you can use to identify view objects in your application.
 Default value is 0
 */
@property (nonatomic,assign) NSInteger tag;

/*!
 @brief Map object type. See the available SYMapObjectTypes.
 */
@property(nonatomic,readonly) SYMapObjectType mapObjectType;

/*!
 @brief Z-index (stacking order) for the SYMapObject.
 Objects with the highest value are placed at the top of the stacking order.
 */
@property(nonatomic,assign) NSUInteger zIndex;

/*!
 @brief Visibility of the SYMapObject. Can be shown or hidden.
 */
@property(nonatomic,assign) BOOL visibility;
@end

/*!
 @brief Marker used to display an icon on a geographical position on a map.
 The map handles proper placement of icons on the screen as well as panning and rotation.
 */
@interface SYMapMarker : SYMapObject
/*!
 @brief Initializes a SYMapMarker instance with the specified SYGeoCoordinate and UIImage for the displayed image.
 */
-(nonnull instancetype)initWithCoordinate:(nonnull SYGeoCoordinate*)coordinate image:(nonnull UIImage*)image;

/*!
 @brief The image displayed at the marker location.
 */
@property(nonatomic,strong,nonnull) UIImage* image;

/*!
 @brief The relative CGPoint position of the SYMapMarker from its anchored location.
 Value of 0,0 is top left location of SYMapMarker, 1,1 is bottom right.
 Default value is 0.5,0.5.
 */
@property(nonatomic,assign) CGPoint anchorPosition;

/*!
 @brief Minimum zoom level, at which SYMapMarker is displayed.
 */
@property(nonatomic,assign) CGFloat minZoomLevel;

/*!
 @brief Maximum zoom level, at which SYMapMarker is displayed.
 */
@property(nonatomic,assign) CGFloat maxZoomLevel;

/*!
 @brief Clickable area insets, defined by margin values from SYMapMarker.image size. Zero by default.
 */
@property(nonatomic,assign) UIEdgeInsets clickableAreaInsets;
@end

/*!
 @brief SYMapObject in the shape of a route that can be displayed on a map.
 In order to display the route object on the map, the route object needs to be added to an SYMapView by calling addMapObject:.
 */
@interface SYMapRoute : SYMapObject
/*!
 @brief Initializes a SYMapRoute instance with the specified SYRoute and SYMapRouteType for the displayed route.
 */
-(nonnull instancetype)initWithRoute:(nonnull SYRoute*)route type:(SYMapRouteType)type;

/*!
 @brief Type of SYMapRoute. See the available SYMapRouteTypes.
 */
@property(nonatomic,readonly) SYMapRouteType routeType;

/*!
 @brief SYRoute represented by the SYMapRoute.
 */
@property(nonatomic,readonly,nonnull) SYRoute* route;

/*!
 @brief Route color.
 */
@property(nonatomic,strong,nullable) UIColor* color;

/*!
 @brief Indicates whether the route object is displaying traffic information.
 */
@property(nonatomic,assign) BOOL trafficVisible;
@end

/*!
 @brief SYMapObject in the shape of a circle.
 In order to display the circle object on the map, the circle object needs to be added to an SYMapView by calling addMapObject:.
 */
@interface SYMapCircle : SYMapObject
/*!
 @brief Initializes a SYCircle instance with the specified center and radius.
 */
-(nonnull instancetype)initWithGeoCenter:(nonnull SYGeoCoordinate*)center radius:(CGFloat)radius;

/*!
 @brief Circle radius in meters.
 */
@property(nonatomic,readonly) CGFloat radius;

/*!
 @brief The line width, in pixels.
 */
@property(nonatomic,assign) NSUInteger lineWidth;

/*!
 @brief The line color.
 */
@property(nonatomic,strong,nonnull) UIColor* lineColor;

/*!
 @brief The fill color.
 */
@property(nonatomic,strong,nullable) UIColor* fillColor;
@end

/*!
 @brief SYMapObject in the shape of a polyline.
 In order to display the polyline object on the map, the polyline object needs to be added to an SYMapView by calling addMapObject:
 */
@interface SYMapPolyline : SYMapObject
/*!
 @brief Initializes a SYMapPolyline instance with the specified SYGeoCoordinates.
 */
-(nonnull instancetype)initWithCoordinates:(nonnull NSArray<SYGeoCoordinate*>*)coordinates;

/*!
 @brief The SYGeoCoordinate array that comprise the path of the SYMapPolyline.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYGeoCoordinate*>* vertices;

/*!
 @brief The line width, in pixels.
 */
@property(nonatomic,assign) NSUInteger lineWidth;

/*!
 @brief The line color.
 */
@property(nonatomic,strong,nonnull) UIColor* primaryColor;

/*!
 @brief The sceondary color used as second color on dashed line or as border color.
 */
@property(nonatomic,strong,nonnull) UIColor* secondaryColor;

/*!
 @brief Indicates whether the SYMapPolyline is dashed.
 */
@property(nonatomic,assign) BOOL dashed;

/*!
 @brief Indicates whether the width od SyMapPolyline is scaled based on ground distance.
 */
@property(nonatomic,assign) BOOL hasScalableWidth;

/*!
 @brief Indicates whether the SyMapPolyline should be rendered with borders.
 */
@property(nonatomic,assign) BOOL hasBorders;

/*!
 @brief The length of the dash segment of the SYMapPolyline.
 */
@property(nonatomic,assign) NSUInteger dashLength;

/*!
 @brief The length of the secondary dash segment of the SYMapPolyline.
 */
@property(nonatomic,assign) NSUInteger dashSecondaryLength;

/*!
 @brief Corner radius for the dash segment of the SYMapPolyline, in range [0, lineWidth / 2].
 Corner radius of size lineWidth / 2 generates circled pattern, otherwise rectangle with rounded corners is generated.
 */
@property(nonatomic,assign) NSUInteger cornerRadius;
@end

/*!
 @brief Represents the class implementation for route label object of SYMapObject.
 SYMapRouteLabel is used to display a label on a route on a map. The map handles proper placement of icons on the screen as well as panning and rotation.
 */
@interface SYMapRouteLabel : SYMapObject

/*!
 @brief Initializes a SYMapRouteLabel instance with the specified text, style and route.
 @param style Can be nil - default SYMapObjectTextStyle will be used.
 */
-(nonnull instancetype)initWithText:(nonnull NSString*)text textStyle:(nullable SYMapObjectTextStyle*)style placeOnRoute:(nonnull SYRoute*)route;

/*!
 @brief Label text.
 */
@property(nonatomic,strong,nonnull) NSString* text;

/*!
 @brief Label text style.
 */
@property(nonatomic,strong,nonnull) SYMapObjectTextStyle* textStyle;

/*!
 @brief Image that will be drawn on label surface.
 */
@property(nonatomic,strong,nonnull) UIImage* image;

/*!
 @brief Label style image, that defines color, shape, and ninepatch properties.
 */
@property(nonatomic,strong,nonnull) UIImage* styleImage;

/*!
 @brief The relative CGPoint position of the SYMapRouteLabel from its anchored location.
 Value of 0,0 is top left location of SYMapRouteLabel, 1,1 is bottom right.
 Default value is 0.0,0.0.
 */
@property(nonatomic,assign) CGPoint anchorPosition;

/*!
 @brief Forced route label size.
 */
@property(nonatomic,assign) CGSize forcedSize;

/*!
 @brief Maximum label image size.
 */
@property(nonatomic,assign) CGSize maxImageSize;

/*!
 @brief Maximum text size.
 */
@property(nonatomic,assign) CGSize maxTextSize;

/*!
 @brief Enables horizontal mirroring of label image.
 Default value is NO.
 */
@property(nonatomic,assign) BOOL horizontalImageMirroringEnabled;

/*!
 @brief Enables vertical mirroring of label image.
 Default value is NO.
 */
@property(nonatomic,assign) BOOL verticalImageMirroringEnabled;

/*!
 @brief Label's route.
 Once SYMapRouteLabel is added to SYMapView, it's position is calculated to be displayed on this route.
 */
@property(nonatomic,readonly,nonnull) SYRoute* route;

/*!
 @brief Minimum zoom level, at which SYMapRouteLabel is displayed.
 */
@property(nonatomic,assign) CGFloat minZoomLevel;

/*!
 @brief Maximum zoom level, at which SYMapRouteLabel is displayed.
 */
@property(nonatomic,assign) CGFloat maxZoomLevel;
@end

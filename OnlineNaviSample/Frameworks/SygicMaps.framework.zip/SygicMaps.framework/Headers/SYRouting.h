#import <Foundation/NSDate.h>
#import <SygicMaps/SYTypes.h>
#import <SygicMaps/SYPositionDataSource.h>

@class SYRoutingOptions, SYGeoBoundingBox, SYWaypoint, SYRoadElement, SYDynamicPenalty, SYManeuver;

/*!
 @brief SYRouteInfo is a base route computed via computeRouteInfo. Contains only base route information.
 */
@interface SYRouteInfo : NSObject
/*!
 @brief Length of the route in meters.
 */
@property(nonatomic,readonly) SYDistance length;

/*!
 @brief Duration of the route in seconds.
 */
@property(nonatomic,readonly) NSTimeInterval duration;

/*!
 @brief The routing options. Check the available SYRoutingOptions.
 */
@property(nonatomic,readonly,nonnull) SYRoutingOptions* options;

/*!
 @brief The smallest SYGeoBoundingBox that contains the entire route.
 */
@property(nonatomic,readonly,nonnull) SYGeoBoundingBox* box;

/*!
 @brief List of SYWaypoints on the route.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYWaypoint*>* waypoints;
@end


/*!
 @brief Collection of maneuvers and roadElements connecting two or more waypoints. Waypoints may be thought of as the input to a route calculation whereas maneuvers are the results of calculating a route.
 */
@interface SYRoute : SYRouteInfo
/*!
 @brief The SYManeuvers on the route.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYManeuver*>* maneuvers;

/*!
 @brief The SYRoadElements on the route.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYRoadElement*>* roadElements;

/*!
 @brief Returns route's transit countries iso codes.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYCountryIso*>* transitCountries;

/*!
 @brief Returns set of road avoids available in specified country.
 */
-(nonnull NSSet<NSNumber*>*)availableAvoidsInCountry:(nonnull SYCountryIso*)country;
@end

/*!
 @brief Routing error types.
 */
typedef NS_ENUM(NSInteger, SYRoutingError)
{
    /*!
     @brief There was no error, route calculation succeeded.
     */
	SYRoutingErrorUnspecifiedFault,
    
    /*!
     @brief Graph error.
     */
	SYRoutingErrorDiscontinuousGraph,
    
    /*!
     @brief Routing canceled by user.
     */
	SYRoutingErrorUserCanceled,
    
    /*!
     @brief There was an out-of-memory error.
     */
	SYRoutingErrorLowMemory,
    
    /*!
     @brief Maximum roads limit has been reached.
     */
	SYRoutingErrorRoadsLimitReached,
    
    /*!
     @brief Front is empty.
     */
	SYRoutingErrorFrontEmpty,
    
    /*!
     @brief The initialization has failed.
     */
	SYRoutingErrorInitializationFailed,
    
    /*!
     @brief The path reconstruction has failed.
     */
	SYRoutingErrorPathReconstructFailed,
    
    /*!
     @brief There was an error because no starting waypoint could be found.
     */
	SYRoutingErrorWrongFromPoint,
    
    /*!
     @brief There was an error because no starting waypoint could be found.
     */
	SYRoutingErrorUserRouteRemoved,
    
    /*!
     @brief The path construction has failed.
     */
	SYRoutingErrorPathConstructFailed,
    
    /*!
     @brief The path could not been found.
     */
	SYRoutingErrorPathNotFound,
    
    /*!
     @brief There was an error because no destination waypoint is unreachable.
     */
	SYRoutingErrorUnreachableTarget,
    
    /*!
     @brief The backward front is empty.
     */
	SYRoutingErrorBackwardFrontEmpty,
    
    /*!
     @brief There was an invalid selection for the route.
     */
	SYRoutingErrorInvalidSelection,
    
    /*!
     @brief Alternative route was rejected.
     */
	SYRoutingErrorAlternativeRejected,
    
    /*!
     @brief Unspecified error while using online routing
     */
    SYRoutingErrorOnlineServiceError,

    /*!
     @brief Online routing not available (app in offline mode or nonexisting service requested)
     */
    SYRoutingErrorOnlineServiceNotAvailable,

    /*!
     @brief Online routing service returned invalid response
     */
    SYRoutingErrorOnlineServiceWrongResponse,
    
    /*!
     @brief Online routing service did not respond
     */
    SYRoutingErrorOnlineServiceTimeout,

	/*!
	 @brief Route from and to points are too close to each other
	 */
	SYRoutingErrorFromAndToPointsTooClose,
	
    /*!
     @brief Unknown error.
     */
	SYRoutingErrorNullHell,
    
    /*!
     @brief No routing service is available to compute route.
     */
    SYRoutingErrorNoComputeCanBeCalled,
    
    /*!
     @brief Saved route deserialization error.
     */
    SYRoutingErrorCouldNotRetrieveSavedRoute,

    /*!
     @brief Trying to use offline routing on online map.
     */
    SYRoutingErrorMapNotAvailable
};

/*!
 @brief The Routing group contains classes, protocols, and enumerations for describing and calculating routes.
 */
@class SYRouting;


/*!
 @brief Represents a delegate to handle SYRoute route calculation updates.
 */
@protocol SYRoutingDelegate <NSObject>
@optional
/*!
 @brief Callback for reporting the progress of route calculation, values range from 0.0 (starting) to 1.0 (complete).
 @param progress The progress of the current routing operation.
 @param routeIndex Computed route index
 */
-(void)routing:(nonnull SYRouting*)routing didUpdateComputingProgress:(float)progress onRoute:(NSUInteger)routeIndex;

/*!
 @brief Callback upon completion of route calculation.
 @param routing SYRouting object
 */
-(void)routingDidStartRouteComputing:(nonnull SYRouting*)routing;

/*!
@brief Callback when a primaty route has been calculated.
@param routing SYRouting object
*/
-(void)routing:(nonnull SYRouting*)routing didComputePrimaryRoute:(nullable SYRoute*)route;

/*!
 @brief Callback when a alternative route has been calculated.
 @param routing SYRouting object
 */
-(void)routing:(nonnull SYRouting*)routing didComputeAlternativeRoute:(nullable SYRoute*)route;

/*!
 @brief Callback when route calculation fails.
 @param error SYRoutingError type
 */
-(void)routing:(nonnull SYRouting*)routing computingFailedWithError:(SYRoutingError)error;

/*!
 @brief Called when compute did finished with success after computeRoute: call.
 @param routing SYRouting object.
 */
-(void)routingDidFinishRouteCompute:(nonnull SYRouting*)routing;

/*!
 @brief Called when quick route is computed.
@param routing SYRouting object.
 @param routeInfo Computed quick route.
 */
-(void)routing:(nonnull SYRouting*)routing didComputeRouteInfo:(nonnull SYRouteInfo*)routeInfo;

/*!
 @brief Called when re-compute did star due to vehicle position change.
 @param routing SYRouting object.
 */
-(void)routingDidStartRouteRecompute:(nonnull SYRouting*)routing;

/*!
 @brief Called when re-compute did finished with success.
 @param routing SYRouting object.
 @param route computed route with start point at current location.
 */
-(void)routing:(nonnull SYRouting*)routing didFinishRouteRecompute:(nonnull SYRoute*)route;
@end

/*!
 @brief Contains classes, protocols, and enumerations for describing and calculating routes.
 */
@interface SYRouting : NSObject
/*!
 @brief Delegate for for notification about route compute progress or state
 */
@property(nonatomic,weak, nullable) id<SYRoutingDelegate> delegate;

/*!
 @brief Set your own penalty for all computings such as traffic, roads, countries
 */
@property(nonatomic,strong,nullable) SYDynamicPenalty* dynamicPenalty;

/*!
 @brief Method will compute route from json string obtained from [SYRouteInfo serialize]
 */
-(void)computeRouteFromJson:(nonnull NSString*)json;

/*!
 @brief This method will compute full SYRoute.
 @param from Start point
 @param to Destination
 @param waypoints Waypoints between start and destination
 @param options SYRoutingOptions if needed
 */
-(void)computeRoute:(nonnull SYWaypoint*)from to:(nonnull SYWaypoint*)to via:(nullable NSArray<SYWaypoint*>*)waypoints withOptions:(nullable SYRoutingOptions*)options;

/*!
 @brief Recompute route, for example when dynamicPenalty has been chagnged.
 */
-(void)recomputeRoute:(nonnull SYRoute*)route;

/*!
 @brief Method will compute SYRouteInfo. Call this method when you want to know only base route info such as duration or length.
 It is faster than computeRoute method which computes also geometry, maneuvers etc..
 */
-(void)computeRouteInfo:(nonnull SYWaypoint*)from to:(nonnull SYWaypoint*)to via:(nullable NSArray<SYWaypoint*>*)waypoints withOptions:(nullable SYRoutingOptions*)options;

/*!
 @brief Cancel current computing request.
 */
-(void)cancelComputing;
@end

/*!
 @brief SYRoutePositionSimulator is for demonstration purposes.
 It simulates position along the route with the average speed of road element.
 It replaces gps source of location and it will affect all map view instances.
 */
@interface SYRoutePositionSimulator : SYSimulatorPositionSource
/*!
 @brief Initialize with route.
 */
-(nullable instancetype)initWithRoute:(nonnull SYRoute*)route;
@end

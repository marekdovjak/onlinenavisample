#import <Foundation/Foundation.h>

/*!
 @brief A single segment of audio output. 
 Audio output should be passed to the SYAudioManager (via the playOutput method) to be played.
 */
@interface SYAudioOutput : NSObject
@end

/*!
 @brief A collection of audio output consisting of one or more WAVE or OGG files.
 */
@interface SYAudioFileOutput : SYAudioOutput

/*!
 @brief List of file paths to the audio files we want to play.
 An example for filepath: NSString *filePath = [[NSBundle mainBundle] pathForResource:@"/example/example/example" ofType:@"wav"];
 */
@property(nonatomic,readonly,nonnull) NSArray<NSString*>* filePaths;

/*!
 @brief Creates an SYAudioFileOutput with the given files. This file can be played through SYAudioManager shared instance as SYAudioManager.sharedAudioManager().playOutput(SYAudioFileOutput)
 */
-(nonnull instancetype)initWithFiles:(nonnull NSArray<NSString*>*)filePaths;
@end

/*!
 @brief A TTS audio output segment consisting of a single string.
 */
@interface SYAudioTTSOutput : SYAudioOutput

/*!
 @brief Text which the TTS should say. 
 */
@property(nonatomic,readonly,nonnull) NSString* text;

/*!
 @brief Creates an SYAudioTTSOutput with the given text string, you want to read. This text can be then played like this SYAudioManager.sharedAudioManager().playOutput( SYAudioTTSOutput)
 */
-(nonnull instancetype)initWithText:(nonnull NSString*)text;
@end

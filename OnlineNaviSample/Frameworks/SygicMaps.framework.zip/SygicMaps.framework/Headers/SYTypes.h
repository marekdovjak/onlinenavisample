#import <Foundation/NSString.h>
#import <CoreGraphics/CGBase.h>

/*!
 @brief Represents distance in meters.
 */
typedef NSUInteger SYDistance;

/*!
 @brief Represents accuracy level of measured coordinates in metres.
 The accuracy level is specified in meters and must be a non-negative real number. AccuracyType is a double type and the (value > 0) condition must be satisfied.
  */
typedef double SYAccuracy;

/*!
 @brief Represents speed in kilometes per hour.
 This type can be used whenever speed information needs to be represented. SpeedType is a double type and the (value > 0) condition must be satisfied.
 */
typedef double SYSpeed;

/*!
 @brief Represents country iso code in ISO 3166-2 format.
The complete ISO-3166-2 encoding list of the countries can be found here: https://en.wikipedia.org/wiki/ISO_3166-2
 */
typedef NSString SYCountryIso;

/*!
 @brief Angle in degrees.
 */
typedef CGFloat SYAngle;

/*!
 @brief SYMapView animation identifier.
 */
typedef NSUInteger SYAnimationId;

/*!
 @brief Represents length in meters.
 */
typedef double SYLength;

/*!
 @brief Represents weight in kilograms.
 */
typedef double SYWeight;

#import <SygicMaps/SYTypes.h>

/*!
 @brief Region type for speed limit.
 */
typedef NS_ENUM(NSInteger, SYSpeedLimitCountry)
{
	SYSpeedLimitCountryAmerica,
	SYSpeedLimitCountryRestOfWorld
};

/*!
 @brief Native speed limit units.
 */
typedef NS_ENUM(NSInteger, SYNativeSpeedLimitUnits)
{
	/*
	 Miles per hour
	 */
	SYNativeSpeedLimitUnitsMph,
	
	/*
	 Kilometers per hour
	 */
	SYNativeSpeedLimitUnitsKmh
};

/*!
 @brief Conditions, in which the speed limit can be different.
 */
typedef NS_ENUM(NSInteger, SYSpeedLimitCondition)
{
	SYSpeedLimitConditionMorning,
	SYSpeedLimitConditionDawn,
	SYSpeedLimitConditionEveningRushHour,
	SYSpeedLimitConditionBusinessHours,
	SYSpeedLimitConditionMorningRushHour,
	SYSpeedLimitConditionSkiSeason,
	SYSpeedLimitConditionOffPeakHours,
	SYSpeedLimitConditionTouristSeason,
	SYSpeedLimitConditionDay,
	SYSpeedLimitConditionAutumn,
	SYSpeedLimitConditionNight,
	SYSpeedLimitConditionSpring,
	SYSpeedLimitConditionNonSchoolHours,
	SYSpeedLimitConditionSummer,
	SYSpeedLimitConditionSchoolHours,
	SYSpeedLimitConditionWinter,
	SYSpeedLimitConditionWhenChildrenArePresent,
	SYSpeedLimitConditionChurchHours,
	SYSpeedLimitConditionHoliday,
	SYSpeedLimitConditionDrySeason,
	SYSpeedLimitConditionSchool,
	SYSpeedLimitConditionHighTide,
	SYSpeedLimitConditionSunriseTillSunset,
	SYSpeedLimitConditionHighWater,
	SYSpeedLimitConditionSunsetTillSunrise,
	SYSpeedLimitConditionLowTide,
	SYSpeedLimitConditionAfternoon,
	SYSpeedLimitConditionLowWater,
	SYSpeedLimitConditionStrongWind,
	SYSpeedLimitConditionSummerSchool,
	SYSpeedLimitConditionEvent,
	SYSpeedLimitConditionWetSeason,
	SYSpeedLimitConditionMarketHours,
	SYSpeedLimitConditionAvalanche,
	SYSpeedLimitConditionUndefinedOccasion,
	SYSpeedLimitConditionFuneral,
	SYSpeedLimitConditionRaceDays,
	SYSpeedLimitConditionHuntingSeason,
	SYSpeedLimitConditionPollution,
	SYSpeedLimitConditionMilitaryExercise,
	SYSpeedLimitConditionDusk,
	SYSpeedLimitConditionThaw,
	SYSpeedLimitConditionEvening,
	SYSpeedLimitConditionRainWetConditions,
	SYSpeedLimitConditionSnow,
	SYSpeedLimitConditionFog
};

/*!
 @brief Represents the actuall speed limit on the route.
 */
@interface SYSpeedLimit : NSObject

/*!
 @brief Get the speed limit in km/h. Zero if the speed limit is not available.
 */
@property(nonatomic,readonly) SYSpeed speedLimit;

/*!
 @brief Represents, if you are heading through Municipality, returns NO if you are not.
 */
@property(nonatomic,readonly) BOOL isInMunicipality;

/*!
 @brief Get the region, in which you want to see the speedlimit.
 */
@property(nonatomic,readonly) SYSpeedLimitCountry country;

/*!
 @brief Native speed limit units used in country where speed limit occurs.
 */
@property(nonatomic,readonly) SYNativeSpeedLimitUnits nativeUnits;
@end


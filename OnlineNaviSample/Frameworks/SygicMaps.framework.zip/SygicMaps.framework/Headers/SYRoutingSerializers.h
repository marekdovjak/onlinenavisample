#import <Foundation/NSObject.h>

@class SYRoute;

/*!
 @brief Provides methods to serialize a route.
 */
@protocol SYRouteSerializer <NSObject>

/*!
 @brief Serialize the route to a JSON file.
 @return JSON file.
 */
-(nullable NSString*)serializeRoute:(nonnull SYRoute*)route;
@end

/*!
 @brief Serializes the route with information needed to compute the route from A to B. Contains route options, waypoints etc.
 */
@interface SYRouteSerializerBrief : NSObject<SYRouteSerializer>
/*!
 @brief Serialize the route to a JSON file.
 @return JSON file.
 */
-(nullable NSString*)serializeRoute:(nonnull SYRoute*)route;
@end

/*!
 @brief Serializes the route with complete geometry information, step by step how the serialized route was computed.
 */
@interface SYRouteSerializerFull : NSObject<SYRouteSerializer>

/*!
 @brief Serialize the route to a JSON file.
 @return JSON file.
 */
-(nullable NSString*)serializeRoute:(nonnull SYRoute*)route;
@end

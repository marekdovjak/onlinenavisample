#import <Foundation/NSString.h>

/*!
 @brief The status of SYTask
 */
typedef NS_ENUM(NSInteger, SYTaskStatus)
{
	SYTaskStatusUnknown,
	SYTaskStatusNotCompleted,
	SYTaskStatusSuccess,
	SYTaskStatusCancelled,
	SYTaskStatusError,
	SYTaskStatusErrorNoInternetConnection,
	SYTaskStatusErrorHttpConnection,
	SYTaskStatusErrorHttpResponse,
	SYTaskStatusErrorHttpRequest,
    SYTaskStatusTimeout
};

/*!
 @brief A cancelable object that refers to the lifetime of processing a given request.
 */
@interface SYTask : NSObject<NSCopying>
/*!
 @brief Task status.
 */
@property(atomic,readonly) SYTaskStatus status;
/*!
 @brief Additional info which may be used to describe the task status further.
 */
@property(atomic,readonly,nullable) NSString* statusInfo;
/*!
 @brief Cancel running task. If task is not running, or already finished, does nothing.
 */
- (void)cancel;
@end

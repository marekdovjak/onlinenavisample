#import <SygicMaps/SYTypes.h>

/*!
 @brief Junction view background types.
 */
typedef NS_ENUM(NSInteger, SYJunctionBackground)
{
    /*!
     @brief No background type.
     */
	SYJunctionBackgroundNone,
    
    /*!
     @brief City background.
     */
	SYJunctionBackgroundCity,
    
    /*!
     @brief Forest background.
     */
	SYJunctionBackgroundForest
};

/*!
 @brief Junction view turn types
 */
typedef NS_ENUM(NSInteger, SYJunctionTurnType)
{
	SYJunctionTurnTypeNone,
	SYJunctionTurnTypeMotorwayExit,
	SYJunctionTurnTypeMotorwayBifurcation,
	SYJunctionTurnTypeMotorwayStraight,
	SYJunctionTurnTypeRoadBifurcation,
	SYJunctionTurnTypeRoadExit
};

/*!
 @brief Junction view turn direction types.
 */
typedef NS_ENUM(NSInteger, SYJunctionTurnDirection)
{
    /*!
     @brief No direction info.
     */
	SYJunctionTurnDirectionNone,
    
    /*!
     @brief Direction left.
     */
	SYJunctionTurnDirectionLeft,
    
    /*!
     @brief Direction right
     */
	SYJunctionTurnDirectionRight
};

/*!
 @brief Provides information about road lanes, including lane directions and turn types.
 */
@interface SYJunctionInfo : NSObject

/*!
 @brief Background type of the upcoming junction info.
 */
@property(nonatomic,readonly) SYJunctionBackground background;

/*!
 @brief Turn type of the upcoming junction info. Check the available SYJunctionTurnType types.
 */
@property(nonatomic,readonly) SYJunctionTurnType turnType;

/*!
 @brief Direction of the upcoming turn. Check the available SYJunctionTurnDirection types.
 */

@property(nonatomic,readonly) SYJunctionTurnDirection turnDirection;

/*!
 @brief Numbers of lanes on road you are travelling on before junction.
 */
@property(nonatomic,readonly) NSInteger fromLanesCount;

/*!
 @brief Numbers of lanes that continues after junction on the left.
 */
@property(nonatomic,readonly) NSInteger toLeftLanesCount;

/*!
 @brief Numbers of lanes that continues after junction on the right.
 */
@property(nonatomic,readonly) NSInteger toRightLanesCount;

/*!
 @brief This flag means, that whole situation described with this object should be drawed mirrored.
		For example when you are in left side driving countries or exit is on the left side.
 */
@property(nonatomic,readonly) BOOL mirroring;
@end

#import <SygicMaps/SYTypes.h>

/*!
 @brief List of Driving side possibilities..
 */
typedef NS_ENUM(NSInteger, SYDrivingSide)
{
    /*!
     @brief Driving on the left side.
     */
	SYDrivingSideLeft,
    
    /*!
     @brief Driving on the right side.
     */
	SYDrivingSideRight,
    
    /*!
     @brief No available information.
     */
	SYDrivingSideUnknown
};


/*!
 @brief Provides additional information about the selected country.
 */
@interface SYMapInfo : NSObject
/*!
 @brief Indicates on which side of the road you drive in selected country.
 For example in UK it is the left side.
 */
@property(nonatomic,assign, readonly) SYDrivingSide drivingSide;
@end

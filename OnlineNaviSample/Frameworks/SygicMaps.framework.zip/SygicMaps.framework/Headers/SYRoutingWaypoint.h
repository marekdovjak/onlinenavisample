#import <Foundation/NSString.h>

@class SYGeoCoordinate;

/*!
 @brief Waypoints types.
 */
typedef NS_ENUM(NSUInteger, SYWaypointType)
{
    /*!
     @brief Start point.
     */
	SYWaypointTypeStart,
    
    /*!
     @brief Waypoint between start and destination
     */
	SYWaypointTypeVia,
    
    /*!
     @brief Destination point.
     */
	SYWaypointTypeEnd,
};

/*!
 @brief Waypoint statuses.
 */
typedef NS_ENUM(NSUInteger, SYWaypointStatus)
{
	/*!
	 @brief Waypoint before vehicle.
	 */
	SYWaypointStatusAhead,
	
	/*!
	 @brief Waypoint passed
	 */
	SYWaypointStatusReached
};

/*!
 @brief Waypoints define a route's stopovers, including its start point it's destination point and any points in between.
 */
@interface SYWaypoint : NSObject

/*!
 @brief Position for flag/pin.
 The original position is required for a route calculation. By default, this is set to be the same as the geocoordinates provided during construction of this SYWaypoint.
 */
@property(nonatomic,nonnull,readonly) SYGeoCoordinate* originalPosition;

/*!
 @brief Represents the suggested navigable position of the SYWaypoint - typically the coordinates on the road closest to the original position - to be used in a route calculation.
 Working together with the navigable position, the original position is used by the Sygic SDK for determining the side of street during arrival, and to let the calculated route approach the correct side of street, especially when there there is a physical or logical lane divider on the road.
 */
@property(nonatomic,nullable,readonly) SYGeoCoordinate* navigablePosition;

/*!
 @brief Represents the mapped matched position of the SYWaypoint.
 This is nil before route calculation. This is only available after route calculation.
 */
@property(nonatomic,nullable,readonly) SYGeoCoordinate* mappedPosition;

/*!
 @brief Determines the waypoint type.
 */
@property(nonatomic,readonly) SYWaypointType type;

/*!
 @brief Determines if waypoint is reached or not.
 */
@property(nonatomic,readonly) SYWaypointStatus status;

/*!
 @brief Waypoint's name.
 */
@property(nonatomic,nullable,readonly) NSString* name;

/*!
 @brief Initializes a SYWaypoint instance with specified geocoordinates and type.
 */
-(nonnull instancetype)initWithPosition:(nonnull SYGeoCoordinate*)position type:(SYWaypointType)type name:(nullable NSString*)name;
@end

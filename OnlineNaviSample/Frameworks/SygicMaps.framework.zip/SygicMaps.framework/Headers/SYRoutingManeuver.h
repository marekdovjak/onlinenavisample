#import <SygicMaps/SYTypes.h>

@class SYGeoCoordinate;

typedef NS_ENUM(NSInteger, SYManeuverType)
{
	SYManeuverTypeNone,
	SYManeuverTypeStart,
	SYManeuverTypeEasyLeft,
	SYManeuverTypeEasyRight,
	SYManeuverTypeEnd,
	SYManeuverTypeVia,
	SYManeuverTypeKeepLeft,
	SYManeuverTypeKeepRight,
	SYManeuverTypeLeft,
	SYManeuverTypeOutOfRoute,
	SYManeuverTypeRight,
	SYManeuverTypeSharpLeft,
	SYManeuverTypeSharpRight,
	SYManeuverTypeStraight,
	SYManeuverTypeUTurnLeft,
	SYManeuverTypeUTurnRight,
	SYManeuverTypeFerry,
	SYManeuverTypeStateBoundary,
	SYManeuverTypeFollow,
	SYManeuverTypeMotorway,
	SYManeuverTypeTunnel,
	SYManeuverTypeRoundabout,
	SYManeuverTypeExit
};

typedef NS_ENUM(NSInteger, SYRoundaboutType)
{
	SYRoundaboutTypeSE,
	SYRoundaboutTypeE,
	SYRoundaboutTypeNE,
	SYRoundaboutTypeN,
	SYRoundaboutTypeNW,
	SYRoundaboutTypeW,
	SYRoundaboutTypeSW,
	SYRoundaboutTypeS,
	SYRoundaboutTypeLeftSE,
	SYRoundaboutTypeLeftE,
	SYRoundaboutTypeLeftNE,
	SYRoundaboutTypeLeftN,
	SYRoundaboutTypeLeftNW,
	SYRoundaboutTypeLeftW,
	SYRoundaboutTypeLeftSW,
	SYRoundaboutTypeLeftS
};

typedef NS_ENUM(NSInteger, SYExitType)
{
	SYExitTypeLeft,
	SYExitTypeRight
};

@interface SYRoad : NSObject
/*!
 @brief The name of the road on which the SYManeuver takes place, nil if not available.
 */
@property(nonatomic,readonly,nullable) NSString* roadName;

/*!
 @brief The number of the road on which the SYManeuver takes place. 
 A short label for the road.
 */
@property(nonatomic,readonly,nullable) NSString* roadNumber;
@end

/*!
 @brief Represents a maneuver, which is the action where you leave one street segment and enter the next one.
 */
@interface SYManeuver : NSObject
/*!
 @brief The SYGeoCoordinate of the maneuver.
 If this maneuver contains one or more transit route elements, this coordinate will be the same as the coordinate of the 1st transit route element.
 */
@property(nonatomic,readonly,nonnull) SYGeoCoordinate* coordinate;

/*!
 @brief Maneuver type. See the available SYManeuverType for more info.
 */
@property(nonatomic,readonly) SYManeuverType type;

/*!
 @brief Distance to maneuver from current on route position.
 */
@property(nonatomic,readonly) SYDistance distanceToManeuver;

/*!
 @brief Distance to maneuver from route start point in meters.
 */
@property(nonatomic,readonly) SYDistance distanceFromStart;

/*!
 @brief zero based index to which waypoint part this maneuver belongs.
 */
@property(nonatomic,readonly) NSUInteger waypointPart;

/*!
 @brief The name of the road on which the SYManeuver takes place, nil if not available
 */
@property(nonatomic,readonly,nullable) SYRoad* road;

/*!
 @brief The road to which the SYManeuver leads, nil if not available. If not available, it should be left blank. 
 */
@property(nonatomic,readonly,nullable) SYRoad* nextRoad;
@end

/*!
 @brief Provides information about the roundabout maneuver.
 */
@interface SYManeuverRoundabout : SYManeuver
/*!
 @brief Specifies the rountabout exit index. Index is the number of exit, you should use. That is why 0 is a invalid number. (index > 0)
 */
@property(nonatomic,readonly) NSUInteger roundaboutExitIndex;

/*!
 @brief Specifies the rountabout type. See the available SYRoundaboutType for more info.
 */
@property(nonatomic,readonly) SYRoundaboutType roundaboutType;
@end

/*!
 @brief Provides information about the Exit maneuver.
 */
@interface SYManeuverExit : SYManeuver

/*!
 @brief Specifies the exit number.
 */
@property(nonatomic,readonly,nullable) NSString* exitNumber;

/*!
 @brief Specifies the exit type. See the available SYExitType for more info.
 */
@property(nonatomic,readonly) SYExitType exitType;
@end

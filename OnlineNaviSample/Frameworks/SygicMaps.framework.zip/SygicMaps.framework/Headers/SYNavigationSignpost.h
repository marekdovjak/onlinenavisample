#import <SygicMaps/SYTypes.h>

@class SYGeoCoordinate, UIColor, SYJunctionInfo;

/*!
 @brief Singpost element types
 */
typedef NS_ENUM(NSInteger, SYSignpostElementType)
{
	SYSignpostElementLineBreak,
	SYSignpostElementRouteNumber,
	SYSignpostElementExitNumber,
	SYSignpostElementStreetName,
	SYSignpostElementExitName,
	SYSignpostElementPictogram,
	SYSignpostElementPlaceName,
	SYSignpostElementOtherDestination
};

/*!
 @brief Singpost element pictogram types
 */
typedef NS_ENUM(NSInteger, SYSignpostElementPictogramType)
{
	SYSignpostElementPictogramNone,
	SYSignpostElementPictogramAirport,
	SYSignpostElementPictogramBusStation,
	SYSignpostElementPictogramFair,
	SYSignpostElementPictogramFerryConnection,
	SYSignpostElementPictogramFirstAidPost,
	SYSignpostElementPictogramHarbour,
	SYSignpostElementPictogramHospital,
	SYSignpostElementPictogramHotelOrMotel,
	SYSignpostElementPictogramIndustrialArea,
	SYSignpostElementPictogramInformationCenter,
	SYSignpostElementPictogramParkingFacility,
	SYSignpostElementPictogramPetrolStation,
	SYSignpostElementPictogramRailwayStation,
	SYSignpostElementPictogramRestArea,
	SYSignpostElementPictogramRestaurant,
	SYSignpostElementPictogramToilet
};

/*!
 @brief Route Number text colors
 */
typedef NS_ENUM(NSInteger, SYNumberTextColor)
{
	SYNumberTextColorUnknown,
	SYNumberTextColorBlack,
	SYNumberTextColorWhite,
	SYNumberTextColorGreenE,
	SYNumberTextColorGreenA,
	SYNumberTextColorBlue,
	SYNumberTextColorBlueNavy,
	SYNumberTextColorBlueMex,
	SYNumberTextColorRed,
	SYNumberTextColorYellow,
	SYNumberTextColorOrange,
	SYNumberTextColorBrown
};

/*!
 @brief Route Number shape types
 */
typedef NS_ENUM(NSInteger, SYNumberShapeType)
{
	SYNumberShapeTypeUnknown,
	SYNumberShapeTypeBrownRect,
	SYNumberShapeTypeWhiteRect,
	SYNumberShapeTypeBlueRect,
	SYNumberShapeTypeRedRect,
	SYNumberShapeTypeOrangeRect,
	SYNumberShapeTypeYellowRect,
	SYNumberShapeTypeBlueNavyRect,
	SYNumberShapeTypeGreenERect,
	SYNumberShapeTypeGreenARect,
	SYNumberShapeTypeGreenERectWhiteBorder,
	SYNumberShapeTypeGreenERectBlackBorder,
	SYNumberShapeTypeBlueRectWhiteBorder,
	SYNumberShapeTypeBlueRectBlackBorder,
	SYNumberShapeTypeRedRectWhiteBorder,
	SYNumberShapeTypeRedRectBlackBorder,
	SYNumberShapeTypeYellowRectBlackBorder,
	SYNumberShapeTypeYellowRectWhiteBorder,
	SYNumberShapeTypeWhiteRectBlackBorder,
	SYNumberShapeTypeWhiteRectGreenEBorder,
	SYNumberShapeTypeGreenARectGreenEBorder,
	SYNumberShapeTypeBlueNavyRectWhiteBorder,
	SYNumberShapeTypeWhiteRectYellowBorder,
	
	SYNumberShapeTypeBlueShape1,
	SYNumberShapeTypeBlueNavyShape2,
	SYNumberShapeTypeGreenEShape2,
	SYNumberShapeTypeGreenEShape3,
	SYNumberShapeTypeGreenAShape4,
	SYNumberShapeTypeRedShape5,
	SYNumberShapeTypeBlueShape5,
	SYNumberShapeTypeBlueShape6,
	SYNumberShapeTypeRedShape6,
	SYNumberShapeTypeGreenEShape6,
	SYNumberShapeTypeBrownShape7,
	SYNumberShapeTypeRedShape8,
	SYNumberShapeTypeRedShape9,
	SYNumberShapeTypeRedShape10,
	
	SYNumberShapeTypeBlackShape11WhiteBorder,
	SYNumberShapeTypeWhiteShape12BlueNavyBorder,
	SYNumberShapeTypeYellowShape13GreenABorder,
	SYNumberShapeTypeWhiteShape14GreenEBorder,
	SYNumberShapeTypeWhiteShape15BlackBorder,
	SYNumberShapeTypeGreenEShape16WhiteBorder,
	SYNumberShapeTypeBlueShape17WhiteBorder,
	SYNumberShapeTypeWhiteShape17BlackBorder,
	SYNumberShapeTypeGreenEShape18WhiteBorder,
	SYNumberShapeTypeBlueShape18BlackBorder,
	SYNumberShapeTypeYellowShape18BlackBorder,
	SYNumberShapeTypeOrangeShape19BlackBorder,
	SYNumberShapeTypeWhiteShape20BlackBorder,
	SYNumberShapeTypeWhiteShape21BlackBorder,
	SYNumberShapeTypeWhiteShape22BlackBorder,
	SYNumberShapeTypeOrangeShape23WhiteBorder,
	SYNumberShapeTypeWhiteShape24BlueMexBorder,
	SYNumberShapeTypeWhiteShape24RedBorder,
	SYNumberShapeTypeWhiteShape24GreenEBorder,
	SYNumberShapeTypeWhiteShape24BlackBorder,
	
	SYNumberShapeTypeBlueMexShape,
	SYNumberShapeTypeRedMexShape,
	SYNumberShapeTypeGreenESauShape1,
	SYNumberShapeTypeGreenESauShape2,
	SYNumberShapeTypeGreenESauShape3,
	SYNumberShapeTypeBlueRedCanShape,
	SYNumberShapeTypeUSAShield
};


/*!
 @brief Singpost route numbers format.
 */
@interface SYRouteNumberFormat : NSObject

/*!
 @brief Array of shapes which should be drawed in this order.
 */
@property(nonatomic,readonly) SYNumberShapeType shape;

/*!
 @brief Formated route number which should be drawed on top of all shapes.
 */
@property(nonatomic,readonly,nonnull) NSString* insideNumber;

/*!
 @brief Text color for insideNumber
 */
@property(nonatomic,readonly) SYNumberTextColor numberColor;
@end


/*!
 @brief Singpost destination label.
 */
@interface SYSignpostElement : NSObject

/*!
 @brief Singpost element type. See the available SYSignpostElementTypes.
 */
@property(nonatomic,readonly) SYSignpostElementType type;

/*!
 @brief Singpost pictogram element type. See the available SYSignpostElementPictogramTypes.
 */
@property(nonatomic,readonly) SYSignpostElementPictogramType pictogram;

/*!
 @brief If type == SYSignpostElementRouteNumber then numberFormat contains information how to draw route number in signpost
 */
@property(nonatomic,readonly,nullable) SYRouteNumberFormat* numberFormat;

/*!
 @brief Singpost destination label text.
 */
@property(nonatomic,readonly,copy,nullable) NSString* text;

/*!
 @brief Singpost destination label priority. Default 0, bigger value = bigger priority = show first
 */
@property(nonatomic,readonly) NSInteger priority;
@end


/*!
 @brief Represents a signpost information for navigation and map display.
 */
@interface SYSignpost : NSObject

/*!
 @brief Represents the text color of the signpost.
 */
@property(nonatomic,readonly,nullable) UIColor* textColor;

/*!
 @brief The background color of the signpost.
 */
@property(nonatomic,readonly,nullable) UIColor* backgroundColor;

/*!
 @brief Represents the border color of the signpost.
 */
@property(nonatomic,readonly,nullable) UIColor* borderColor;

/*!
 @brief Distance to signpost from current on route position.
 */
@property(nonatomic,readonly) SYDistance distance;

/*!
 @brief Signpost geographical position.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* position;

/*!
 @brief Shows, if signpost is part of current route navigation. If it is not, returns no.
 */
@property(nonatomic,readonly) BOOL isOnRoute;

/*!
 @brief Array of all SYSignpostElements.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYSignpostElement*>* elements;

/*!
 @brief Information about image representing the signpost situation.
 */
@property(nonatomic,readonly,nullable) SYJunctionInfo* junctionInfo;

/*!
 @brief Singpost priority. Default 0, bigger value = bigger priority = show first
 */
@property(nonatomic,readonly) NSInteger priority;
@end

#import <SygicMaps/SYPlacesObjects.h>

/*!
 @brief Represents custom favorites data.
 */
@interface SYSearchFavorite : NSObject
-(nonnull instancetype)initWithPosition:(nonnull SYGeoCoordinate*)position title:(nonnull NSString*)title subTitle:(nullable NSString*)subTitle;
/*!
 @brief Title.
 */
@property (nonatomic,strong,nonnull) NSString* title;
/*!
 @brief Subtitle.
 */
@property (nonatomic,strong,nullable) NSString* subTitle;
/*!
 @brief Geoposition.
 */
@property (nonatomic,strong,nonnull) SYGeoCoordinate* position;
/*!
 @brief Custom application data.
 */
@property (nonatomic,strong,nonnull) NSObject* payload;
@end

/*!
 @brief Represents custom poi data.
 */
@interface SYSearchCustomPoi : NSObject
-(nonnull instancetype)initWithPosition:(nonnull SYGeoCoordinate*)position title:(nonnull NSString*)title subTitle:(nullable NSString*)subTitle;
/*!
 @brief Title.
 */
@property (nonatomic,strong,nonnull) NSString* title;
/*!
 @brief Subtitle.
 */
@property (nonatomic,strong,nullable) NSString* subTitle;
/*!
 @brief Geoposition.
 */
@property (nonatomic,strong,nonnull) SYGeoCoordinate* position;
/*!
 @brief Custom application data.
 */
@property (nonatomic,strong,nonnull) NSObject* payload;
@end

/*!
 @brief Represents custom search history data.
 */
@interface SYSearchHistory : NSObject
-(nonnull instancetype)initWithPosition:(nonnull SYGeoCoordinate*)position title:(nonnull NSString*)title subTitle:(nullable NSString*)subTitle category:(SYPoiCategory)category timestamp:(nonnull NSDate*)timestamp;
/*!
 @brief Title.
 */
@property (nonatomic,strong,nonnull) NSString* title;
/*!
 @brief Subtitle.
 */
@property (nonatomic,strong,nullable) NSString* subTitle;
/*!
 @brief Geoposition.
 */
@property (nonatomic,strong,nonnull) SYGeoCoordinate* position;
/*!
 @brief Poi cateogry, default value is SYPoiCategoryUnknown (in case history data is not a poi).
 */
@property (nonatomic,assign) SYPoiCategory poiCategory;
/*!
 @brief Timestamp.
 */
@property (nonatomic,strong,nonnull) NSDate* timestamp;
/*!
 @brief Custom application data.
 */
@property (nonatomic,strong,nonnull) NSObject* payload;
@end

/*!
 @brief Represents custom contact data.
 */
@interface SYSearchContact : NSObject
-(nonnull instancetype)initWithTitle:(nonnull NSString*)title address:(nullable NSString*)address;

/*!
 @brief Contact's title.
 */
@property (nonatomic,strong,nonnull) NSString* title;
/*!
 @brief Contact's address.
 */
@property (nonatomic,strong,nonnull) NSString* address;
/*!
 @brief Custom application data.
 */
@property (nonatomic,strong,nonnull) NSObject* payload;
@end

/*!
 @brief Represents a interface for adding custom search data.
 */
@interface SYSearchCustomDataSource : NSObject
-(void)addHistory:(nonnull NSArray<SYSearchHistory*>*)history;
-(void)addFavorites:(nonnull NSArray<SYSearchFavorite*>*)favorites;
-(void)addContacts:(nonnull NSArray<SYSearchContact*>*)contacts;
-(void)addCustomPois:(nonnull NSArray<SYSearchCustomPoi*>*)customPois;
-(void)clearAllData;
@end

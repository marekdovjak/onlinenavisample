#import <SygicMaps/SYSearch.h>
#import <SygicMaps/SYPlacesObjects.h>

@class SYPlace, SYTask;

/*!
 @brief Represents a request to retrieve a SYPlace objects.
 */
@interface SYPlaceRequest : SYRequest
/*!
 @brief Option to enable third party data source services
 */
@property (nonatomic,assign) BOOL enableThirdPartySource;
-(nonnull instancetype)initWithLocation:(nonnull SYGeoCoordinate*)location searchRadius:(SYDistance)radius poiGroupfilter:(SYPoiGroup)filter;
-(nonnull instancetype)initWithLocation:(nonnull SYGeoCoordinate*)location searchRadius:(SYDistance)radius poiCategoryfilter:(SYPoiCategory)filter;
@end

/*!
 @brief Represents a set of data about a physical place.
 */
@interface SYPlaces : NSObject
/*!
 @brief Returns SYPlaces singleton instance
 */
+(nonnull SYPlaces*)sharedPlaces;

/*!
 @brief SYPlaces is singleton, use [SYPlaces sharedPlaces] to access singleton instance.
 */
-(nonnull instancetype)init __attribute__((unavailable("Use +[SYPlaces sharedPlaces] instead.")));
+(nonnull SYPlaces*)new __attribute__((unavailable("Use +[SYPlaces sharedPlaces] instead.")));

/*!
 @brief Invokes an asynchronous places search request with a specified completion block.
 */
-(nonnull)startRequest:(nonnull SYPlaceRequest*)placeRequest withCompletion:(nonnull void(^)(NSArray<SYPlace*>* _Nonnull results, SYRequestResultState state))completion;

/*!
 @brief Load place detail information about map POI object.
 */
-(nullable SYTask*)loadPoiObjectPlace:(nonnull SYPoiObject*)poi withCompletion:(nonnull void(^)(SYPlace* _Nonnull poiPlace))completion;

/*!
 @brief Load place detail information about POI info object.
 */
-(nullable SYTask*)loadPoiInfoPlace:(nonnull SYPoiInfo*)poiInfo withCompletion:(nonnull void(^)(SYPlace* _Nonnull poiPlace))completion;

/*!
 @brief Load detail information about map city object.
 */
-(nullable SYTask*)loadCityObjectName:(nonnull SYCityObject*)city withCompletion:(nonnull void(^)(NSString* _Nonnull cityName))completion;
@end

#import <Foundation/NSObject.h>
#import <SygicMaps/SYTypes.h>

@class NSDate, NSSet, NSNumber, NSDictionary;

/*!
 @brief Represents values describing different routing types.
 SYRoutingType has no effect on SYTransportModePedestrian or SYTransportModePublicTransport transport modes.
 */
typedef NS_ENUM(NSInteger, SYRoutingType)
{
    /*!
     @brief Search for the fastest route, taking road conditions and restrictions into account (minimizes travel time).
     */
	SYRoutingTypeFastest,
    
    /*!
     @brief Search for the shortest route, taking road conditions and restrictions into account (minimizes travel distance). Car mode only.
     */
	SYRoutingTypeShortest,
    
    /*!
     @brief Search for economic route, some travel time may be sacrificed in order to reduce the distance traveled. It calculates the optimal route based on time and distance combination. Car mode only.
     */
	SYRoutingTypeEconomic
};

/*!
 @brief Represents values describing different transport modes, the mode of transportation a person will be using to travel a route (e.g. a car).
 */
typedef NS_ENUM(NSInteger, SYTransportMode)
{
    /*!
     @brief Unknown transport mode type.
     */
	SYTransportModeUnknown,
    
    /*!
     @brief A car is set as the transport mode.
     */
	SYTransportModeCar,
    
    /*!
     @brief Walking is set as the transport mode.
     */
	SYTransportModePedestrian,
    
//	SYTransportModePublicBus,
//	SYTransportModeBicycle,
//	SYTransportModeTaxi,
//	SYTransportModeHighOccupancyVehicle,
//	SYTransportModeTransportTruck,
//	SYTransportModeDeliveryTruck,
//	SYTransportModeEmergencyVehicle
};

/*!
 @brief Shows values describing routing options that can be used to enforce special conditions on a calculated route.
 Please note, that all of them can be only used with car transport mode.
 */
typedef NS_ENUM(NSInteger, SYAvoidType)
{
    /*!
     @brief No avoids.
     */
	SYAvoidTypeNone,
    
    /*!
     @brief Routing will avoid links that are part of a toll road.
     */
	SYAvoidTypeToll,
    
    /*!
     @brief Routing will avoid links that are part of a ferry.
     */
	SYAvoidTypeFerries,
    
    /*!
     @brief Routing will avoid links that are part of a motorway.
     */
	SYAvoidTypeMotorway,
    
    /*!
     @brief Routing will avoid links that are part of an special area.
     */
	SYAvoidTypeSpecialArea,
    
    /*!
     @brief Routing will avoid links that are part of an unpaved roads.
     */
	SYAvoidTypeUnpavedRoads
};

/*!
 @brief Class representing complex options available to route calculation.
 */
@interface SYRoutingOptions : NSObject <NSCopying>
/*!
 @brief Routing type for SYRoutingOptions.
 Default value is SYRoutingTypeFastest.
 */
@property(nonatomic,assign) SYRoutingType routingType;

/*!
 @brief Transport mode for SYRoutingOptions.
 Default value is SYTransportModeCar.
 */
@property(nonatomic,assign) SYTransportMode transportMode;

/*!
 @brief SYAvoidType values stored as [NSNumber numberWithInteger:] for global routing avoids.
 Default value is SYAvoidTypeNone.
 */
@property(nonatomic,strong,nullable) NSSet<NSNumber*>* globalAvoids;

/*!
 @brief Dictionary of country avoids (SYAvoidType values stored as [NSNumber numberWithInteger:]) per country.
 */
@property(nonatomic,strong,nullable) NSDictionary<SYCountryIso*,NSSet<NSNumber*>*>* countryAvoids;

/*!
 @brief The desired departure time.
 Set to nil to use current time.
 */
@property(nonatomic,strong,nullable) NSDate* departureTime;

/*!
 @brief Option to enable/disable alternative route calculation.
 Default value is YES.
 */
@property(nonatomic,assign) BOOL computeAlternativeRoutes;
@end

/*!
 @brief Contains options used when calculating a truck route.
 */
@interface SYRoutingOptionsTruck: SYRoutingOptions
/*!
 Gross vehicle weight.
 */
@property(nonatomic,assign) SYWeight totalWeight;

/*!
 Weight per axle.
 */
@property(nonatomic,assign) SYWeight axleWeight;

/*!
 Tandem axle weight.
 */
@property(nonatomic,assign) SYWeight tandemWeight;

/*!
 Tandem axle weight.
 */
@property(nonatomic,assign) SYWeight tridemWeight;

/*!
 Other weight.
 */
@property(nonatomic,assign) SYWeight otherWeight;

/*!
 Unladen vehicle weight.
 */
@property(nonatomic,assign) SYWeight unladenWeight;

/*!
 Total vehicle length.
 */
@property(nonatomic,assign) SYLength totalLength;

/*!
 Extreme axle length.
 */
@property(nonatomic,assign) SYLength axleLength;

/*!
 Trailer Length.
 */
@property(nonatomic,assign) SYLength trailerLength;

/*!
 Tractor Length.
 */
@property(nonatomic,assign) SYLength tractorLength;

/*!
 Kingpin to last axle.
 */
@property(nonatomic,assign) SYLength kingpinLastAxle;

/*!
 Kingpin to middle of last tandem.
 */
@property(nonatomic,assign) SYLength kingpinLastTandem;

/*!
 Kingpin to end of trailer (last trailer if applicable).
 */
@property(nonatomic,assign) SYLength kingpinEndTrailer;

/*!
 Other length.
 */
@property(nonatomic,assign) SYLength otherLength;

/*!
 Vehicle width.
 */
@property(nonatomic,assign) SYLength width;

/*!
 Posted height.
 */
@property(nonatomic,assign) SYLength height;
@end

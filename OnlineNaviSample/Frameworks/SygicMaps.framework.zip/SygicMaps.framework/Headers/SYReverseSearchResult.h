#import <SygicMaps/SYTypes.h>

@class SYGeoCoordinate, SYGeoBoundingBox;

/*!
 @brief Provides description of the found result
 */
@interface SYReverseSearchResultDescription : NSObject
/*!
 @brief City of the found result.
 */
@property(nonatomic,readonly,nullable) NSString* city;

/*!
 @brief Street of the found result.
 */
@property(nonatomic,readonly,nullable) NSString* street;

/*!
 @brief Road numbers of the found result.
 */
@property(nonatomic,readonly,nullable) NSArray<NSString*>* roadNumbers;

/*!
 @brief House number of the found result, if available.
 */
@property(nonatomic,readonly,nullable) NSString* houseNumber;

/*!
 @brief Build Up area of the found result, if available.
 */
@property(nonatomic,readonly,nullable) NSString* builtUpArea;

/*!
 @brief Country iso.
 */
@property (nonatomic,readonly,nonnull) SYCountryIso* countryIso;
@end

/*
 @brief Represents the result of a reverse geocode request.
 The data of a reverse geocode result is represented by an instance of SYReverseSearchResultDescription, accessed through the resultDescription property.
 */
@interface SYReverseSearchResult : NSObject

/*!
 @brief Textual description of the found result. See the available SYReverseSearchResultDescription for more info.
 */
@property(nonatomic,readonly,nonnull) SYReverseSearchResultDescription* resultDescription;

/*!
 @brief Timezone in which the result is.
 */
@property(nonatomic,readonly) NSInteger timezone;

/*!
 @brief Exact position of the found result.
 */
@property(nonatomic,readonly,nonnull) SYGeoCoordinate* coordinate;

/*!
 @brief Bounding box of the search result.
 */
@property(nonatomic,readonly,nonnull) SYGeoBoundingBox* boundingBox;

/*!
 @brief Distance of the found result from the current position.
 */
@property(nonatomic,readonly) SYDistance distance;

@end

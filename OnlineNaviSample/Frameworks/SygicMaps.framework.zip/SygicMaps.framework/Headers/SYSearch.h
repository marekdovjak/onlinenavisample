#import <Foundation/NSObject.h>

@class NSString, SYSearchResult, SYMapSearchResult, SYSearchCustomDataSource, SYSearchResultDetail, SYGeoCoordinate, SYGeoBoundingBox;

/*!
 @brief The possible types of connectivity mode that the request is performed.
 */
typedef NS_ENUM(NSUInteger, SYRequestResultState)
{
	SYRequestResultStateSuccess,
	SYRequestResultStateError,
	SYRequestResultStateNotAvailable,
	SYRequestResultStateCancelled,
	SYRequestResultStateWrongResponse,
	SYRequestResultStateTimeout
};

/*!
 @brief Represents a base interface for a search request.
 */
@interface SYRequest : NSObject
/*!
 @brief The maximum number of items in the response. Default value is 10.
 */
@property (nonatomic,assign) NSUInteger maxResultsCount;
/*!
 @brief NSString representing the preferred language for request responses.
 Default Value is [[NSLocale preferredLanguages] objectAtIndex:0].
 */
@property (nonatomic,strong,nonnull) NSString* preferredLanguage;
@end

/*!
 @brief Represents an interface for a search request.
 */
@interface SYSearchRequest : SYRequest
/*!
 @brief Creates a geocoder request that resolves a free text query.
 */
-(nonnull instancetype)initWithQuery:(nonnull NSString*)query atLocation:(nullable SYGeoCoordinate*)coordinate;
@end

/*!
 @brief Represents an interface for a SYSearchResult detail request.
 */
@interface SYSearchResultDetailRequest : SYRequest
-(nonnull instancetype)initWithResult:(nonnull SYMapSearchResult*)result atLocation:(nonnull SYGeoCoordinate*)coordinate;
/*!
 @brief The SYSearchResult, which details will be requested.
 */
@property (nonatomic,strong,nonnull) SYSearchResult* searchResult;
/*!
 @brief The location where search detail request will be performed. In most cases, this is the location of SYSearchResult. In cases like searching details of poi
 category or poi group (when SYSearchResult has no location), client application has to determine the location (e.g. current gps location, or map view center).
 */
@property (nonatomic,strong,nonnull) SYGeoCoordinate* location;
/*!
 @brief The bounding box in which to perform the search detail request.
 */
@property (nonatomic,strong,nullable) SYGeoBoundingBox* boundary;
@end

/*!
 @brief The Search class processes text string queries based on the user's input to find specific places.
 */
@interface SYSearch : NSObject
/*!
 The additional data providers for search.
 */
@property (nonatomic,readonly,nonnull) SYSearchCustomDataSource* customDataSources;
/*!
 @brief Class providing search functions for location data.
 @param request SYSearchRequest object containing all the required search parameters
 @param completion Block called when search is complete
 */
-(void)startSearchRequest:(nonnull SYSearchRequest*)request withCompletion:(nonnull void(^)(NSArray<SYSearchResult*>* _Nonnull results, SYRequestResultState state))completion;
/*!
 @brief Request details like, coordinate, distance, area boudary for search result.
 */
-(void)startSearchDetailRequest:(nonnull SYSearchResultDetailRequest*)request withCompletion:(nonnull void(^)(SYSearchResultDetail* _Nullable detail, SYRequestResultState state))completion;
@end

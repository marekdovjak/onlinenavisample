#import <Foundation/NSObject.h>

//! Project version number for Sygic.
FOUNDATION_EXPORT double SygicVersionNumber;

//! Project version string for Sygic.
FOUNDATION_EXPORT const unsigned char SygicVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Sygic/PublicHeader.h>
#import <SygicMaps/SYAudioData.h>
#import <SygicMaps/SYAudioManager.h>
#import <SygicMaps/SYAudioOutput.h>
#import <SygicMaps/SYAudioSettings.h>
#import <SygicMaps/SYContext.h>
#import <SygicMaps/SYCustomContent.h>
#import <SygicMaps/SYDriving.h>
#import <SygicMaps/SYLaneAssistView.h>
#import <SygicMaps/SYMapInfo.h>
#import <SygicMaps/SYMapObjects.h>
#import <SygicMaps/SYMapObjectsCluster.h>
#import <SygicMaps/SYMapAnimations.h>
#import <SygicMaps/SYMapAnnotations.h>
#import <SygicMaps/SYMapView.h>
#import <SygicMaps/SYMapViewLayers.h>
#import <SygicMaps/SYMapLoader.h>
#import <SygicMaps/SYMapPositionIndicator.h>
#import <SygicMaps/SYNavigation.h>
#import <SygicMaps/SYNavigationInstruction.h>
#import <SygicMaps/SYNavigationJunction.h>
#import <SygicMaps/SYNavigationLaneInformation.h>
#import <SygicMaps/SYNavigationPoi.h>
#import <SygicMaps/SYNavigationSignpost.h>
#import <SygicMaps/SYNavigationSpeedLimit.h>
#import <SygicMaps/SYNavigationWarnings.h>
#import <SygicMaps/SYNavigationWarningsSettings.h>
#import <SygicMaps/SYOnlineSession.h>
#import <SygicMaps/SYPlaces.h>
#import <SygicMaps/SYPlace.h>
#import <SygicMaps/SYPlacesLocationInfo.h>
#import <SygicMaps/SYPlacesObjects.h>
#import <SygicMaps/SYPositioning.h>
#import <SygicMaps/SYPositionDataSource.h>
#import <SygicMaps/SYReverseSearch.h>
#import <SygicMaps/SYReverseSearchResult.h>
#import <SygicMaps/SYRouting.h>
#import <SygicMaps/SYRoutingManeuver.h>
#import <SygicMaps/SYRoutingOptions.h>
#import <SygicMaps/SYRoutingPenalty.h>
#import <SygicMaps/SYRoutingSerializers.h>
#import <SygicMaps/SYRoutingRoadElement.h>
#import <SygicMaps/SYRoutingWaypoint.h>
#import <SygicMaps/SYSearch.h>
#import <SygicMaps/SYSearchCustomDataSource.h>
#import <SygicMaps/SYSearchResult.h>
#import <SygicMaps/SYSearchResultDetail.h>
#import <SygicMaps/SYTraffic.h>
#import <SygicMaps/SYTask.h>
#import <SygicMaps/SYTypes.h>
#import <SygicMaps/SYVoiceCatalog.h>
#import <SygicMaps/SYViewObjects.h>

#import <Foundation/NSObject.h>

@class SYGeoCoordinate;

/*!
 @brief ViewObject types
 */
typedef NS_ENUM(NSInteger, SYViewObjectType)
{
	SYViewObjectTypeScreen,
	SYViewObjectTypeMap,
	SYViewObjectTypeProxy
};

/*!
 @brief Base class for objects shown in an SYMapView view.
 All objects displayed by an Sygic SDK view have SYViewObject as their base class. All such objects fall into one of two categories: proxy objects, created by the SDK, and user objects, created by the client application. These objects additionally inherit from SYViewObjects.
 */

@interface SYViewObject : NSObject
/*!
 @brief Geographical location of the SYViewObject.
 The meaning of the location for a particular object depends on that object's type. Objects that don't have a location will return nil. The meaning of the location for certain view objects is as follows:
 
 SYMapView objects:
 SYMapObjectTypePoint - has location.
 SYMapObjectTypeSafetySpot - has location
 SYMapObjectTypeReserved - has location
 SYMapObjectTypeCircle - the center of the circle
 SYMapObjectTypeContainer - no location
 SYMapObjectTypeMarker - has location
 SYMapObjectTypeLabelMarker - has location
 SYMapObjectTypePolygon - the first vertex
 SYMapObjectTypePolyline - the first vertex
 SYMapObjectTypeRoute - the first waypoint of the route
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* coordinate;

/*!
 @brief Determines which type of this ViewObject it is.
 */
@property(nonatomic,readonly) SYViewObjectType baseType;
@end

/*!
 @brief ProxyObject types
 */
typedef NS_ENUM(NSInteger, SyProxyObjectType)
{
	SyProxyObjectTypePoi,
	SyProxyObjectTypeCity,
    SyProxyObjectTypeRadar
};

/*!
 @brief Base class for all view objects created by Sygic SDK.
 */
@interface SYProxyObject : SYViewObject

/*!
 @brief Determines which type of this ProxyObject it is.
 */
@property(nonatomic,readonly) SyProxyObjectType type;
@end

#import <Foundation/NSObjCRuntime.h>

/*!
 @brief Map layer category type enum.
 */
typedef NS_ENUM(NSInteger,SYMapLayerCategory)
{
	SYMapLayerCategoryLabelAddressPoints,
	SYMapLayerCategoryLabelCityCenters,
	SYMapLayerCategoryLabelCountry,
	SYMapLayerCategoryBorderCountry,
	SYMapLayerCategoryAreas,
	SYMapLayerCategoryCityMaps,
	SYMapLayerCategoryCollections,
	SYMapLayerCategoryGlobe,
	SYMapLayerCategoryRouteJunctions,
	SYMapLayerCategoryLandmarks,
	SYMapLayerCategoryMapObjects,
	SYMapLayerCategoryPois,
	SYMapLayerCategoryRoads,
	SYMapLayerCategoryRoutes,
	SYMapLayerCategorySky,
	SYMapLayerCategoryRadars,
	SYMapLayerCategorySmartLabels,
	SYMapLayerCategoryTerrain,
	SYMapLayerCategoryTraffic,
	SYMapLayerCategoryPositionIndicator,
    SYMapLayerCategoryWarningSpeedLimit,
    SYMapLayerCategoryWarningRadar,
    SYMapLayerCategoryWarningSharpCurve
};

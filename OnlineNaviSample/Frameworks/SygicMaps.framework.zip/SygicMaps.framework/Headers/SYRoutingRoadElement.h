#import <Foundation/NSDate.h>
#import <SygicMaps/SYTypes.h>

@class SYGeoCoordinate;

/*!
 @brief Road element attribute classifications
 Describes the nature of the road that a SYRoadElement is part of. A road element may only have one type, or none if the road is an unclassified type or the information is not available.
 */
typedef NS_ENUM(NSInteger, SYRoadElementAttribute)
{
	SYRoadElementAttributeRamp,
	SYRoadElementAttributeHighway,
	SYRoadElementAttributeUrban,
	SYRoadElementAttributeLogistics,
	SYRoadElementAttributeFerry,
	SYRoadElementAttributeBrunnel,
	SYRoadElementAttributeRoundAbout,
	SYRoadElementAttributeNoThroughTraffic,
	SYRoadElementAttributeWalkway,
	SYRoadElementAttributePedestrianZone,
	SYRoadElementAttributeScenicRoute,
	SYRoadElementAttributeTollRoad,
	SYRoadElementAttributePaved,
    SYRoadElementAttributeSpecialArea
};

/*!
 @brief Direction types of Road elements.
 */
typedef NS_ENUM(NSInteger, SYRoadElementDirection)
{
	SYRoadElementDirectionUndefined,
	SYRoadElementDirectionNoCars,
	SYRoadElementDirectionForward,
	SYRoadElementDirectionBackward,
	SYRoadElementDirectionBoth,
};

/*!
 @brief Represents a road element on the road.
 */
@interface SYRoadElement : NSObject

/*!
 @brief The length of SYRoadElement in meters.
 */
@property(nonatomic,readonly) SYDistance length;

/*!
 @brief The duration of SYRoadElement in seconds based on average speed
 of the element.
 */
@property(nonatomic,readonly) NSTimeInterval duration;

/*!
 @brief The distance from start of SYRoute in meters.
 */
@property(nonatomic,readonly) SYDistance distance;

/*!
 @brief The speed limit of SYRoadElement in kmh, or 0 if the information is not available.
 */
@property(nonatomic,readonly) SYSpeed speedLimit;

/*!
 @brief Direction of SYRoadElement.
 */
@property(nonatomic,readonly) SYRoadElementDirection direction;

/*!
 @brief The colection of SYRoadElementAttribute.
 */
@property(nonatomic,readonly,nullable) NSSet<NSNumber*>*  attributes;

/*!
 @brief Represents country iso code.
 */
@property(nonatomic,readonly,nullable) SYCountryIso*  country;

/*!
 @brief The unique identifier of SYRoadElement
 */
@property(nonatomic,readonly,nullable) NSString*  uniqueId;

/*!
 @brief The name of the road element, or an empty string if the data is not available.
 */
@property(nonatomic,readonly,nullable) NSString*  roadName;

/*!
 @brief From coordinate.
 */
@property(nonatomic,readonly,nonnull) SYGeoCoordinate* from;

/*!
 @brief To coordinate.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* to;
@end

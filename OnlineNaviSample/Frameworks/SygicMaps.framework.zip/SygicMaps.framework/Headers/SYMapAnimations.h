#import <SygicMaps/SYTypes.h>
#import <Foundation/NSObjCRuntime.h>

/*!
 @brief Specifies the supported animation curves.
 */
typedef NS_ENUM(NSInteger, SYMapAnimationCurve)
{
    /*!
     @brief A linear animation curve causes an animation to occur evenly over its duration.
     */
	SYMapAnimationCurveLinear,
    
    /*!
     @brief This curve causes the animation to accelerate.
     */
	SYMapAnimationCurveAccelerate,
    /*!
     @brief This curve causes the animation to slow down.
     */
	SYMapAnimationCurveDecelerate,
    /*!
     @brief This curve causes the animation to accelerate first and decelerate at the end.
     */
	SYMapAnimationCurveAccelerateDecelerate,
    /*!
     @brief This curve will toggle the animation to bounce.
     */
	SYMapAnimationCurveBounce
};

static SYAnimationId SYAnimationIdNone = 0;
typedef void (^SYAnimationCompletionBlock)(SYAnimationId animId, BOOL success);

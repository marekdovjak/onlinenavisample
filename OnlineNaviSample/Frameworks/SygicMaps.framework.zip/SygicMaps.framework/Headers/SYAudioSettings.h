#import <SygicMaps/SYTypes.h>

/*!
 @brief Available distance units.
 */
typedef NS_ENUM(NSInteger, SYAudioDistanceUnits)
{
    /*!
     @brief Miles / yards.
     */
	SYAudioDistanceUnitsMilesYards,
    
    /*!
     @brief Kilometers.
     */
	SYAudioDistanceUnitsKilometers,
    
    /*!
     @brief Miles / feets.
     */
	SYAudioDistanceUnitsMilesFeets
};

/*!
 @brief Mode, how the warning should be represented.
 */
typedef NS_OPTIONS(NSInteger, SYAudioWarningMode)
{
    /*!
     @brief Vibration.
     */
	SYAudioWarningModeVibrate = 0x1,
    
    /*!
     @brief Use TTS voice.
     */
	SYAudioWarningModeUseTts = 0x2,
    
    /*!
     @brief Use default TTS voice.
     */
	SYAudioWarningModeUseDefaultTts = 0x4
};

/*!
 @brief Generic audio settings for warnings. You can set your custom voice or TTS for various cases.
 */
@interface SYAudioWarningSettings : NSObject
/*!
 @brief Path to the warning sound file.
 */
@property(nonatomic,nullable,copy) NSString*	warningSoundPath;

/*!
 @brief Text, we want to be played as the warning sound.
 */
@property(nonatomic,nullable,copy) NSString*	ttsText;

/*!
 @brief Warning mode. See the available SYAudioWarningModes.
 */
@property(nonatomic,assign) SYAudioWarningMode mode;
@end

/*!
 @brief Audio settings for speed camera warnings.
 */
@interface SYSpeedCameraAudioWarningSettings : SYAudioWarningSettings
@end

/*!
 @brief Audio settings for speed limit warnings.
 */
@interface SYSpeedLimitAudioWarningSettings : SYAudioWarningSettings
@end

/*!
 @brief Audio settings for speed limit warnings.
 */
@interface SYRailwayCrossingAudioWarningSettings : SYAudioWarningSettings
@end

/*!
 @brief Audio settings for traffic warnings.
 */
@interface SYTrafficAudioWarningSettings : SYAudioWarningSettings
@end

/*!
 @brief Audio settings for better route warnings.
 */
@interface SYBetterRouteAudioWarningSettings : SYAudioWarningSettings
@end

/*!
 @brief Audio settings for danger turn warnings.
 */
@interface SYDangerTurnAudioWarningSettings : SYAudioWarningSettings
/*!
 @brief Sharp curve warning easy curve angle in degrees.
 */
@property(nonatomic,assign) SYAngle dangerTurnEasyAngle;

/*!
 @brief Sharp curve warning medium curve angle in degrees.
 */
@property(nonatomic,assign) SYAngle dangerTurnMediumAngle;

/*!
 @brief Sharp curve warning hard curve angle in degrees.
 */
@property(nonatomic,assign) SYAngle dangerTurnHardAngle;
@end

/*!
 @brief Audio settings for parking warnings.
 */
@interface SYParkingAudioWarningSettings : SYAudioWarningSettings
@end

/*!
 @brief Class defines settings for audio notifications.
 */
@interface SYAudioSettings : NSObject
/*!
 @brief Speed camera audio warning settings.
 */
@property(nonatomic,readonly,nonnull) SYSpeedCameraAudioWarningSettings* speedCameraWarning;

/*!
 @brief Danger turn audio warning settings.
 */
@property(nonatomic,readonly,nonnull) SYDangerTurnAudioWarningSettings* dangerTurnWarning;

/*!
 @brief Speed limit audio warning settings.
 */
@property(nonatomic,readonly,nonnull) SYSpeedLimitAudioWarningSettings* speedLimitWarning;

/*!
 @brief Railway crossing audio warning settings.
 */
@property(nonatomic,readonly,nonnull) SYRailwayCrossingAudioWarningSettings* railwayCrossingWarning;

/*!
 @brief Traffic warning audio warning settings.
 */
@property(nonatomic,readonly,nonnull) SYTrafficAudioWarningSettings* trafficWarning;

/*!
 @brief Better route audio warning settings.
 */
@property(nonatomic,readonly,nonnull) SYBetterRouteAudioWarningSettings* betterRouteWarning;

/*!
 @brief Parking audio warning settings.
 */
@property(nonatomic,readonly,nonnull) SYParkingAudioWarningSettings* parkingWarning;

/*!
 @brief Enable road number reading in instructions.
 */
@property(nonatomic,assign) BOOL readRoadNumbers;

/*!
 @brief Enable road names reading in instructions.
 */
@property(nonatomic,assign) BOOL readRoadNames;

/*!
 @brief Enable city names reading in instructions.
 */
@property(nonatomic,assign) BOOL readCityNames;

/*!
 @brief Set units for TTS warnings. See the available SYAudioDistanceUnits.
 */
@property(nonatomic,assign) SYAudioDistanceUnits unitSettings;

/*!
 @brief Minimum distance of the road after instruction to be read as ".. and go along street".
 */
@property(nonatomic,assign) SYDistance goAlongDistance;

/*!
 @brief Minimum distance between two instructions to be read as "... then immediately ...".
 */
@property(nonatomic,assign) SYDistance immediatelyDistance;

/*!
 @brief Reset all settings to default.
 */
-(void)resetToDefault;

@end


#import <SygicMaps/SYTypes.h>
#import <SygicMaps/SYPlacesObjects.h>

@class NSString, SYGeoCoordinate, SYLocationInfo;

/*!
 @brief Represents a set of data about a physical place.
 */
@interface SYPlace : NSObject
/*!
 @brief Represents the place name. For example: Sydney opera house, Statue of Liberty.
 */
@property (nonatomic,readonly,nonnull) NSString* name;
/*!
 @brief Geographical location of the POI.
 */
@property (nonatomic,readonly,nonnull) SYGeoCoordinate* coordinate;
/*!
 @brief The information for the location represented by the place object.
 */
@property(nonatomic,readonly,nullable) SYLocationInfo* locationInfo;
/*!
 @brief POI category.
 */
@property (nonatomic,readonly) SYPoiCategory category;
/*!
 @brief POI parent group.
 */
@property (nonatomic,readonly) SYPoiGroup group;
/*!
 @brief Place country iso.
 */
@property (nonatomic,readonly,nonnull) SYCountryIso* countryIso;
/*!
 @brief Represents the place's brand name.
 */
@property (nonatomic,readonly,nonnull) NSString* brandName;
@end

/*!
 @brief SYFuel types.
 */
typedef NS_ENUM(NSUInteger, SYFuel)
{
	SYFuelPetrol,
	SYFuelDiesel,
	SYFuelCNG,
	SYFuelLPG
};

/*!
 @brief Represents a fuel price data.
 */
@interface SYFuelPrice : NSObject
/*!
 @brief Fuel price.
 */
@property (nonatomic, readonly) double price;
/*!
 @brief Price currency.
 */
@property (nonatomic,readonly,nonnull) NSString* currency;
/*!
 @brief Fuel type.
 */
@property (nonatomic,readonly) SYFuel fuelType;
/*!
 @brief Fuel subtype.
 */
@property (nonatomic,readonly,nullable) NSString* fuelSubType;
@end

/*!
 @brief Represents a set of data about the petrol station.
 */
@interface SYPetrolStation : SYPlace
@property (nonatomic,readonly,nonnull) NSSet<SYFuelPrice*>* fuelPrices;
@end

/*!
 @brief Parking price types.
 */
typedef NS_ENUM(NSUInteger, SYParkingPriceLevel)
{
	SYParkingPriceLevelUnknown,
	SYParkingPriceLevelFree,
	SYParkingPriceLevelNumeric
};

/*!
 @brief Parking free space levels.
 */
typedef NS_ENUM(NSUInteger, SYParkingFreeSpace)
{
	SYParkingFreeSpaceUnknown,
	SYParkingFreeSpaceLow,
	SYParkingFreeSpaceMedium,
	SYParkingFreeSpaceHigh
};

/*!
 @brief Parking type.
 */
typedef NS_ENUM(NSUInteger, SYParkingType)
{
	SYParkingTypeUnknown,
	SYParkingTypeCarpark,
	SYParkingTypeMeter,
	SYParkingTypePrivate,
	SYParkingTypeStreet
};

/*!
 @brief Represents a set of data about the parking place.
 */
@interface SYParking : SYPlace
/*!
 @brief Parking price.
 */
@property (nonatomic,readonly,nullable) NSString* price;
/*!
 @brief Parking price level.
 */
@property (nonatomic,readonly) SYParkingPriceLevel priceLevel;
/*!
 @brief Free space indicator.
 */
@property (nonatomic,readonly) SYParkingFreeSpace freeSpace;
/*!
 @brief Parking type.
 */
@property (nonatomic,readonly) SYParkingType type;
/*!
 @brief Available parking spaces.
 */
@property (nonatomic,readonly) NSInteger availableSpaces;
/*!
 @brief Additional information.
 */
@property (nonatomic,readonly,nullable) NSString* additionalInformation;
@end

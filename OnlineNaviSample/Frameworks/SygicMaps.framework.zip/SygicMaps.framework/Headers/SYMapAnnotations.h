#import <UIKit/UIView.h>

@class SYGeoCoordinate;

/*!
 @brief SYAnnotation
 */
@interface SYAnnotation : NSObject
@property (nonatomic,nonnull) SYGeoCoordinate* coordinate;
@property (nonatomic,assign) NSInteger tag;
@end

/*!
 @brief SYAnnotationView
 */
@interface SYAnnotationView : UIView
@property (nonatomic,readonly,nullable) NSString *reuseIdentifier;
@property (nonatomic,strong,nullable) SYAnnotation* annotation;
/*!
 @brief By default, SYAnnotationView [0,0] point is placed over the coordinate of the annotation. anchorPoint is the offset in screen points from the [0,0] point of SYAnnotationView.
 */
@property (nonatomic,assign) CGPoint anchorPoint;
-(nonnull instancetype)initWithAnnotation:(nullable SYAnnotation*)annotation reuseIdentifier:(nullable NSString *)reuseIdentifier;
/*!
 @brief Called when SYAnnotationView is being reused. Classes that override must call super.
 */
-(void)prepareForReuse;
@end

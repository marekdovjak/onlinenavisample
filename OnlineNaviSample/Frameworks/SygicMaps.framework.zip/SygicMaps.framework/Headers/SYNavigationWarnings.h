#import <SygicMaps/SYTypes.h>
#import <SygicMaps/SYRouting.h>

@class SYGeoCoordinate;

/*!
 @brief Base class for warning notifications. Includes all warnings you can get during navigation.
 */
@interface SYWarning : NSObject
/*!
 @brief Distance to warning from current on route position.
 */
@property(nonatomic,readonly) SYDistance distance;

/*!
 @brief Warning crossing position.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* position;

@end

/*!
 @brief Railway crossing warning.
 */
@interface SYRailwayCrossing : SYWarning
@end

/*!
 @brief Radar types
 */
typedef NS_ENUM(NSInteger, SYRadarType)
{
    SYRadarTypeRadarStaticSpeed,
    SYRadarTypeRadarStaticRedLight,
    SYRadarTypeRadarSemiMobileSpeed,
    SYRadarTypeRadarStaticAverageSpeed,
    SYRadarTypeRadarStaticAverageSpeedMiddle,
    SYRadarTypeRadarStaticAverageSpeedEnd,
    SYRadarTypeRadarMobileSpeed,
    SYRadarTypeRadarStaticRedLightSpeed,
    SYRadarTypeRadarMobileRedLight,
    SYRadarTypeRadarMobileAverageSpeed,
    SYRadarTypeRadarFake,
    SYRadarTypeInfoCamera,
    SYRadarTypeDangerousPlace,
    SYRadarTypeDangerousPlaceObjectOnRoad,
    SYRadarTypeDangerousPlaceRoadConstruction,
    SYRadarTypeDangerousPlaceBrokenTrafficLight,
    SYRadarTypeDangerousPlacePothole,
    SYRadarTypeDangerousPlaceVehicleStopped,
    SYRadarTypeDangerousPlaceAnimalAccident,
    SYRadarTypeTraffic,
    SYRadarTypeTrafficModerate,
    SYRadarTypeTrafficHeavy,
    SYRadarTypeTrafficStandstill,
    SYRadarTypeWeightCheck,
    SYRadarTypeDistanceCheck,
    SYRadarTypeClosure,
    SYRadarTypeSchoolzone,
    SYRadarTypePolice,
    SYRadarTypePolicePatrol,
    SYRadarTypePoliceTripod,
    SYRadarTypeCrash,
    SYRadarTypeCrashMinor,
    SYRadarTypeCrashMajor,
    SYRadarTypeWeather,
    SYRadarTypeWeatherHeavyFog,
    SYRadarTypeWeatherHail,
    SYRadarTypeWeatherFlood,
    SYRadarTypeWeatherIce,
    SYRadarTypeWeightCheckFixed,
    SYRadarTypeWeightCheckMobile,
    SYRadarTypeTheft,
    SYRadarTypeTheftGoods,
    SYRadarTypeTheftFuel,
    SYRadarTypeTheftOther,
    SYRadarTypeHelp,
    SYRadarTypeHelpPuncture,
    SYRadarTypeHelpPressure,
    SYRadarTypeHelpHealthIssue,
    SYRadarTypeHelpOther,
    SYRadarTypeUnspecified
};

/*!
 @brief Warning about radars on the route.
 */
@interface SYRadar : SYWarning
/*!
 @brief Radar type. Check the SYRadarTypes for more information.
 */
@property(nonatomic,readonly) SYRadarType radarType;
@property(nonatomic,readonly) NSInteger radarId;
@end

/*!
@brief Sharp curve directions
 */
typedef NS_ENUM(NSInteger, SYSharpCurveDirection)
{
    /*!
     @brief Sharp curve left direction
     */
	SYSharpCurveDirectionLeft,
    
    /*!
     @brief Sharp curve right direction
     */
	SYSharpCurveDirectionRight
};

/*!
 @brief Information about sharp curve warnings.
 */
@interface SYSharpCurve : SYWarning
/*!
 @brief Recommended maximum speed.
 */
@property(nonatomic,readonly) SYSpeed speed;

/*!
 @brief Turn direction.
 */
@property(nonatomic,readonly) SYSharpCurveDirection direction;

/*!
 @brief Turn angle.
 */
@property(nonatomic,readonly) CGFloat angle;

@end

/*!
 @brief Provides information about alternative calculated route.
 */
@interface SYAlternativeRoute : SYRoute
/*!
@brief Time difference in seconds between new alternative route and the base route
 */
@property(nonatomic,readonly) NSTimeInterval timeDiff;

/*!
 @brief Length difference in meters between new alternative route and the base route.
 */
@property(nonatomic,readonly) SYDistance	 lengthDiff;

/*!
 @brief Distance in meters from base route start position to point, where alternative route splits.
 */
@property(nonatomic,readonly) SYDistance	 splitDistance;

/*!
 @brief Geo boundary created with split point and merge point of base route and alternative route.
 */
@property(nonatomic,readonly,nullable) SYGeoBoundingBox* detourAreaboundary;

/*!
 @brief Position of the point where alternative route splits the base route.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* splitPoint;
@end

/*!
 @brief Additional information to the highway exit.
 */
@interface SYHighwayExit : SYWarning
/*!
 @brief Highway exit name.
 */
@property(nonatomic,readonly,nullable) NSString* exitName;

/*!
 @brief Highway exit number.
 */
@property(nonatomic,readonly,nullable) NSString* exitNumber;
@end

/*!
 @brief Exposes additional information about a the route.
 */
@interface SYOnRouteInfo : NSObject

/*!
 @brief Distance in meters from current navigation route position to the end of this route
 */
@property(nonatomic,readonly) SYDistance	 distanceToEnd;

/*!
 @brief Time in seconds from current navigation route position to the end of this route
 */
@property(nonatomic,readonly) NSTimeInterval timeToEnd;

/*!
 @brief Progress on current navigation route. (from 0.0 to 1.0)
 */
@property(nonatomic,readonly) CGFloat routeProgress;
@end

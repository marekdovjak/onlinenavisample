#import <Foundation/NSObject.h>

@class SYAudioPCMData,SYAudioOutput;

typedef void(^PCMDataReadyBlock)(NSArray<SYAudioPCMData*>* _Nonnull);
typedef void(^TTSDataReadyBlock)(NSString* _Nonnull);

@class SYAudioManager;

/*!
 @brief Audio routing mode.
 */
typedef NS_ENUM(NSInteger, SYAudioRoute)
{
	/*!
	 @brief Standard iOS audio routing behaviour.
	 */
	SYAudioRouteDefault,
	
	/*!
	 @brief Force audio output to the device speaker.
	 */
	SYAudioRouteDeviceSpeaker,
	
	/*!
	 @brief Force audio output to a device that supports Bluetooth HFP.
	 */
	SYAudioRouteBluetoothHFP
};

/*!
 @brief Audio playback options.
 */
typedef NS_ENUM(NSInteger, SYAudioPlaybackMode)
{
	/*!
	 @brief Pause music during navigation audio playback.
	 */
	SYAudioPlaybackModePauseMusic,
	
	/*!
	 @brief Fade out other audio during navigation audio playback.
	 */
	SYAudioPlaybackModeFadeOthers
};

/*!
 @brief Audio manager status.
 */
typedef NS_ENUM(NSInteger, SYAudioManagerStatus)
{
	/*!
	 @brief SYAudioManager starts playing audio output.
	 */
	SYAudioManagerStatusPlayingAudio,
	
	/*!
	 @brief SYAudioManager finished playing audio output.
	 */
	SYAudioManagerStatusFinishedPlaying,
	
	/*!
	 @brief SYAudioManager error.
	 */
	SYAudioManagerStatusError
};

/*!
 @brief Represents a delegate that offers listeners and callback methods related to SYAudioManager functionality.
 Methods of this protocol are called on the main queue.
 */
@protocol SYAudioManagerDelegate <NSObject>
@optional
/*!
 @brief Called when SYAudioManager audio play status has changed.
 */
-(void)audioManager:(nonnull SYAudioManager*)manager didChangeStatus:(SYAudioManagerStatus)status;
@end

/*!
 @brief Manages the playback of audio output from files or TTS.
 */
@interface SYAudioManager : NSObject
/*!
 @brief SYAudioManagerDelegate,
 */
@property(nonatomic,weak,nullable) id<SYAudioManagerDelegate> delegate;

/*!
 @brief Controls whether the SYAudioManager manages the application's audio session.
 If managesAudioSession is YES, the SYAudioManager will change the type of the audio session and activate and deactivate the session as necessary to play SDK audio output.
 The default value is YES.
 */
@property(nonatomic,assign) BOOL managesAudioSession;

/*!
 @brief The current audio output route.
 Effective only if SYAudioManager.managesAudioSession is set to YES.
 */
@property(nonatomic,assign) SYAudioRoute audioRoute;

/*!
 @brief Controls interaction with other audio sources. Effective only if SYAudioManager.managesAudioSession is set to YES.
 */
@property(nonatomic,assign) SYAudioPlaybackMode playbackMode;

/*!
 @brief Accesses the SYAudioManager singleton instance.
 @return SYAudioManager instance. 
 */
+(nonnull SYAudioManager*)sharedAudioManager;

/*!
 @brief SYAudioManager is singleton, use [SYAudioManager sharedAudioManager] to access singleton instance.
 */
-(nonnull instancetype)init __attribute__((unavailable("Use +[SYAudioManager sharedAudioManager] instead.")));
+(nonnull SYAudioManager*)new __attribute__((unavailable("Use +[SYAudioManager sharedAudioManager] instead.")));

/*!
 @brief Plays audio output. 
 If audio output queue is empty, output will be played immediately. Otherwise it will be added to the end of the queue and played later.
 */
-(void)playOutput:(nonnull SYAudioOutput*)output;

/*!
 @brief Skips the output at the front of the queue.
 If the current output has already started playing, it will be interrupted. The next output item in the queue will be played.
 */
-(void)skipCurrentOutput;

/*!
 @brief Stops playing the current output immediately and clears any queued output.
 */
-(void)stopOutputAndClearQueue;

/*!
 @brief Removes all output from the audio queue
 Currently played output will be allowed to finish.
 */
-(void)clearQueue;

/*!
 @brief Use this method to get raw PCM audio data and override SYAudioManager PCM audio output with custom solution.
 Pass nil to use default SYAudioManager PCM output.
 */
-(void)redirectPCMOutput:(nullable PCMDataReadyBlock)customPCMPlay;

/*!
 @brief Use this method to get TTS data and override SYAudioManager TTS output with custom solution.
 Pass nil to use default SYAudioManager TTS output.
 */
-(void)redirectTTSOutput:(nullable TTSDataReadyBlock)customTTSPlay;
@end

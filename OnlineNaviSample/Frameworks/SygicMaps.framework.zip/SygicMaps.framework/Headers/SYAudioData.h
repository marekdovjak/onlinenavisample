#import <Foundation/Foundation.h>

/*!
 Class representing PCM audio data.
 */
@interface SYAudioPCMData : NSObject
@property(nonatomic,readonly) NSData* data;
@property(nonatomic,readonly) NSUInteger channels;
@property(nonatomic,readonly) NSUInteger samplesPerSecond;
@property(nonatomic,readonly) NSUInteger bitsPerSample;
@property(nonatomic,readonly) NSUInteger averageBytesPerSecond;
@property(nonatomic,readonly) NSUInteger blockAlign;
@end

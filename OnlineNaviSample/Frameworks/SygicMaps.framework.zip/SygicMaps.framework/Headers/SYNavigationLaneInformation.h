#import <SygicMaps/SYTypes.h>

@class SYGeoCoordinate;

/*!
 @brief Marking types for the divider marking.
 */
typedef NS_ENUM(NSInteger, SYLaneMarking)
{
	SYLaneMarkingNone,
	SYLaneMarkingLongDashed,
	SYLaneMarkingSingleSolidLine, 
	SYLaneMarkingDoubleSolidLine,
	SYLaneMarkingInnerSolidOuterDashed,
	SYLaneMarkingInnerDashedOuterSolid,
	SYLaneMarkingShortDashed,
	SYLaneMarkingTollBoth
};

/*!
 @brief SYEndType.
 */
typedef NS_ENUM(NSInteger, SYEndType)
{
	SYEndTypeNone,
	SYEndTypeForming,
	SYEndTypeEnding,
	SYEndTypeFormingEnding,
	SYEndTypeJunction
};

/*!
 @brief SYLaneDirection.
 */
typedef NS_OPTIONS(NSInteger, SYLaneDirection)
{
	SYLaneDirectionNoDirIndicated = 0x0,
	SYLaneDirectionStraight = 0x1,
	SYLaneDirectionHalfRight = 0x2,
	SYLaneDirectionRight = 0x4,
	SYLaneDirectionSharpRight = 0x8,
	SYLaneDirectionUTurnLeft = 0xF,
	SYLaneDirectionSharpLeft = 0x10,
	SYLaneDirectionLeft = 0x20,
	SYLaneDirectionHalfLeft = 0x40,
	SYLaneDirectionUTurnRight = 0x80,
};

/*!
 @brief SYLaneType.
 */
typedef NS_ENUM(NSInteger, SYLaneType)
{
	SYLaneTypeNotSpecified,
	SYLaneTypeExitEntrance,
	SYLaneTypeShoulderEmergency,
	SYLaneTypeParking,
	SYLaneTypeHOV
};

/*!
 @brief SYMinVehicleOccupancy.
 */
typedef NS_ENUM(NSInteger, SYMinVehicleOccupancy)
{
	SYMinVehicleOccupancyUnknown,
	SYMinVehicleOccupancyDriver,
	SYMinVehicleOccupancyDriverAnd1,
	SYMinVehicleOccupancyDriverAnd2,
	SYMinVehicleOccupancyDriverAnd3,
	SYMinVehicleOccupancyDriverAnd4
};

/*!
 @brief SYSingleOccupancy.
 */
typedef NS_ENUM(NSInteger, SYSingleOccupancy)
{
	SYSingleOccupancyUnknown,
	SYSingleOccupancyCleanFuelService,
	SYSingleOccupancyTollPaymanet
};

/*!
 @brief Gives information about a lane, e.g. its type, markings.
 */
@interface SYLane : NSObject

/*!
 @brief Lane divider marking.
 */
@property(nonatomic,readonly) SYLaneMarking marking;

/*!
 @brief Lane forming end type.
 */
@property(nonatomic,readonly) SYEndType endType;


/*!
 @brief Lane type.
 */
@property(nonatomic,readonly) SYLaneType type;


/*!
 @brief Lane minimum vehicle occupancy.
 */
@property(nonatomic,readonly) SYMinVehicleOccupancy minOccupancy;


/*!
 @brief Lane single occupancy.
 */
@property(nonatomic,readonly) SYSingleOccupancy singleOccupancy;


/*!
 @brief Lane arrows symbols.
 */
@property(nonatomic,readonly) SYLaneDirection arrows;

/*!
 @brief Lane speed restriction.
 */
@property(nonatomic,readonly) SYSpeed speedRestriction;

/*!
 @brief Recommendation state of the lane according to the current route.
 */
@property(nonatomic,readonly) BOOL highlighted;

/*!
 @brief Connected lanes.
 */
@property(nonatomic,readonly,nullable) NSArray<SYLane*>* connectedLanes;
@end

/*!
 @brief Information about a road and its lanes.
 */
@interface SYRoadLanes : NSObject
/*!
 @brief Road's SYLanes. The lanes are ordered from right (index = 0) to left (index = lanes.count - 1), independent of driving side.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYLane*>* lanes;

/*!
 @brief Road geometry.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYGeoCoordinate*>* geometry;

/*!
 @brief The SYDistance from route start to this SYRoadLanes.
 */
@property(nonatomic,readonly) SYDistance routeStartDistance;

/*!
 @brief Driving side information.
 */
@property(nonatomic,readonly) BOOL rightSideDriving;

/*!
 @brief Road z-index.
 */
@property(nonatomic,readonly) NSInteger roadLevel;

/*!
 @brief Number defining side offset (number of lanes) of current SYRoadLanes lanes from previous SYRoadLanes lanes. 
 Positive value means lanes are shifted to left, zero value means no offset and negative value means right offset. 
 In following example, there are 4 SYRoadLanes: 

	4.	| | | |
	3.	| | | |
	2.	| | |/
	1.	| | |
	0.	| | |
 
	SYRoadLanes with index 0 has 2 SYLanes and connectedLanesOffset = 0.
	SYRoadLanes with index 1 has 2 SYLanes and connectedLanesOffset = 0.
	SYRoadLanes with index 2 has 3 SYLanes and connectedLanesOffset = 1.
	SYRoadLanes with index 3 has 3 SYLanes and connectedLanesOffset = 0.
	SYRoadLanes with index 4 has 3 SYLanes and connectedLanesOffset = 0.
 */
@property(nonatomic,readonly) NSInteger connectedLanesOffset;
@end

/*!
 @brief Information about a on-route road and its lanes.
 */
@interface SYRouteRoadLanes : SYRoadLanes
/*!
 @brief Roads which are leaving current route.
 */
@property(nonatomic,readonly,nullable) NSArray<SYRoadLanes*>* leavingRoads;
/*!
 @brief Information about the next SYRouteRoadLanes.
 */
@property(nonatomic,readonly,nullable) SYRouteRoadLanes* nextRoad;
@property(nonatomic,readonly) BOOL isComplexJunction;
@end

/*!
 @brief Complex information about route lanes. 
 Can be used to generate simplified lane assist, which contains information about lanes on current vehicle position. Or to generate complex 3d view of road lanes. 
 */
@interface SYLanesInformation : NSObject
/*!
 @brief Lane information on current vehicle position.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYLane*>* simpleLaneInformation;
/*!
 @brief Complex information about lanes.
 */
@property(nonatomic,readonly,nonnull) SYRouteRoadLanes* comlpexLaneInformation;
/*!
 @brief YES if lanes information is available on current vehicle position. 
 */
@property(nonatomic,readonly) BOOL isActive;
@end



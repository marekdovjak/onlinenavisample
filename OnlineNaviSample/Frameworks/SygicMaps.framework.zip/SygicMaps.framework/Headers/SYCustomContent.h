#import <Foundation/NSObject.h>

@class NSString, UIImage;

/*!
 @brief ...
 */
@interface SYCustomContent : NSObject
-(void)unload;
@end

/*!
 @brief ...
 */
@protocol SYCustomContentIconsDataSource <NSObject>
@required
/*!
 @brief ...
 */
-(nonnull UIImage*)SYCustomContent:(nonnull SYCustomContent*)content iconForIdentifier:(nonnull NSString*)identifier;
@end

/*!
 @brief ...
 */
@interface SYCustomJsonPoiContent : SYCustomContent
-(nonnull instancetype)initWithContentsOfFile:(nonnull NSString*)filePath;
@property(nonatomic,weak,nullable) id<SYCustomContentIconsDataSource> iconsDataSource;
@end

#import <SygicMaps/SYTypes.h>

@class SYRoadElement, SYTrafficEvent;

/*!
 @brief Defines the possible avoid modes used for route calculation and traffic event handling.
 */
@class SYTrafficEvent;
@interface SYDynamicPenalty : NSObject

/*!
 @brief Set to avoid the whole country.
 */
@property(nonatomic,nullable,strong) NSSet<SYCountryIso*>* avoidCountries;

/*!
 @brief Set to avoid specific road elements.
 */
@property(nonatomic,nullable,strong) NSSet<SYRoadElement*>* avoidRoadElements;

/*!
 @brief Set to avoid some traffic events.
 */
@property(nonatomic,nullable,strong) NSSet<SYTrafficEvent*>* avoidTrafficElements;

@end

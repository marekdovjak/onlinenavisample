#import <Foundation/NSObject.h>

/*!
 @brief Online session statuses
 */
typedef NS_ENUM(NSInteger, SYOnlineSessionStatus)
{
	SYOnlineSessionStatusUnknown,
	SYOnlineSessionStatusDisconnected,
	SYOnlineSessionStatusAuthenticationInvalid,
	SYOnlineSessionStatusCreatingSession,
	SYOnlineSessionStatusConnectedWithoutSession,
	SYOnlineSessionStatusConnected
};

@class SYOnlineSession;

/*!
 @brief Callback messages sent by the SYOnlineSession.
 */
@protocol SYOnlineSessionDelegate <NSObject>
@required
/*
 @brief Called when current status of SYOnlineSession has changed.
 */
-(void)onlineSession:(nonnull SYOnlineSession*)session didChangeStatus:(SYOnlineSessionStatus)status;
@end

@interface SYOnlineSession : NSObject
/*!
 @brief Current SYOnlineSession delegate.
 */
@property(nonatomic,assign,nullable) id<SYOnlineSessionDelegate> delegate;

/*!
 @brief Indicates whether Sygic SDK is allowed to access online maps services.
 */
@property(nonatomic,assign) BOOL onlineMapsEnabled;

/*!
 @brief Current connection status of SYOnlineSession.
 */
@property(nonatomic,readonly) SYOnlineSessionStatus status;

/*
 @brief Accesses the SYOnlineSession singleton object
 */
+(nonnull SYOnlineSession*)sharedSession;

/*!
 @brief SYOnlineSession is singleton, use [SYOnlineSession sharedSession] to access singleton instance.
 */
-(nonnull instancetype)init __attribute__((unavailable("Use +[SYOnlineSession sharedSession] instead.")));
+(nonnull SYOnlineSession*)new __attribute__((unavailable("Use +[SYOnlineSession sharedSession] instead.")));
@end

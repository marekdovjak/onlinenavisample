#import <Foundation/NSObject.h>
#import <SygicMaps/SYTypes.h>

@class SYTask, SYMapInfo, NSString;

/*!
 @brief A collection of map packages representing a particular region.
 */
@interface SYMapLoaderMapGroup : NSObject
/*!
 @brief Unique map collection id.
 */
@property(nonatomic,readonly,nonnull) NSString* groupId;
/*!
 @brief Title of map the collection.
 */
@property(nonatomic,readonly,nonnull) NSString* title;
@end

/*!
 @brief Result types of SYMapLoaderLoadPackage.
 */
typedef NS_ENUM(NSInteger, SYMapLoaderLoadPackageResult)
{
	/*!
	 @brief Unknown error.
	 */
	SYMapLoaderLoadPackageResultUnknown,

	/*!
	 @brief Package load was successful.
	 */
	SYMapLoaderLoadPackageResultLoadSuccess,

	/*!
	 @brief Package unload was successful.
	 */
	SYMapLoaderLoadPackageResultUnloadSuccess,

	/*!
	 @brief Map folder does not exist.
	 */
	SYMapLoaderLoadPackageResultWrongMapFolder,

	/*!
	 @brief No map license was found.
	 */
	SYMapLoaderLoadPackageResultNoLicence,

	/*!
	 @brief Map license is invalid.
	 */
	SYMapLoaderLoadPackageResultWrongLicense,

	/*!
	 @brief No map license.
	 */
	SYMapLoaderLoadPackageResultNoLicenseForMap
};

/*!
 @brief Current status of one map package.
 */
typedef NS_ENUM(NSInteger, SYMapLoaderMapPackageStatus)
{
	/*!
	 @brief Package is not installed.
	 */
	SYMapLoaderMapPackageStatusNotInstalled,

	/*!
	 @brief Package is installed and loaded.
	 */
	SYMapLoaderMapPackageStatusLoaded,

	/*!
	 @brief Package is installed but not loaded. To load package use SYMapLoader::loadMapPackages
	 */
	SYMapLoaderMapPackageStatusUnloaded,

	/*!
	 @brief Package is currently in installation process.
	 */
	SYMapLoaderMapPackageStatusInstalling,

	/*!
	 @brief Package is uninstalling.
	 */
	SYMapLoaderMapPackageStatusUninstalling,

	/*!
	 @brief Package update is available.
	 */
	SYMapLoaderMapPackageStatusUpdateAvailable
};

/*!
 @brief Progress of package installation task.
 */
@interface SYPackageInstallProgress : NSObject
/*!
 @brief Total size of package in bytes to download.
 */
@property(nonatomic,readonly) NSUInteger totalSize;

/*!
 @brief Downloaded part of package in bytes.
 */
@property(nonatomic,readonly) NSUInteger downloadedSize;
@end

/*!
 @brief Map data representing a particular country. Map data packages can be selectively installed or uninstalled using the NMAMapLoader API. Installing a package makes its data available for offline usage.
 */
@interface SYMapLoaderMapPackage : NSObject

/*!
 @brief Unique map package id.
 */
@property(nonatomic,readonly,nonnull) NSString* packageId;

/*!
 @brief Map package title.
 */
@property(nonatomic,readonly,nonnull) NSString* title;

/*!
 @brief Size in bytes the map package will take up on disk.
 */
@property(nonatomic,readonly) NSUInteger sizeOnDisk;

/*!
 @brief Map iso code.
 Can be nil in case of globe map.
 */
@property(nonatomic,readonly,nullable) SYCountryIso* countryIso;

/*!
 @brief Map subregion id.
 */
@property(nonatomic,readonly,nullable) NSString* subregionId;

/*!
 @brief Indicates whether map package is representing globe map.
 */
@property(nonatomic,readonly) BOOL isGlobe;

/*!
 @brief List of map subregion packages.
 */
@property(nonatomic,readonly,nullable) NSArray<SYMapLoaderMapPackage*>* subregions;

/*!
 @brief Current map package status. Check the SYMapLoaderMapPackageStatus for available statuses.
 */
-(SYMapLoaderMapPackageStatus)status;
@end

@class SYMapLoader;

/*!
 @brief Callback messages sent by the SYMapLoader. The callbacks correspond to specific map loader functionality. Only one delegate may be installed on the map loader at a time, using the setDelegate method.
 */
@protocol SYMapLoaderDelegate <NSObject>
@optional
/*!
 @brief Called when SYMapLoader::installMapPackage: method is completed.
 @param maploader The SYMapLoader instance sending the callback.
 @param package The SYMapLoaderMapPackage for this operation.
 @param task The original SYTask with status information.
 */
-(void)mapLoader:(nonnull SYMapLoader*)maploader didInstallMapPackage:(nonnull SYMapLoaderMapPackage*)package fromTask:(nonnull SYTask*)task;

/*!
 @brief Called when SYMapLoader::uninstallMapPackage: method is completed.
 @param maploader The SYMapLoader instance sending the callback.
 @param package The SYMapLoaderMapPackage for this operation.
 @param task The original SYTask with status information.
 */
-(void)mapLoader:(nonnull SYMapLoader*)maploader didUninstallMapPackage:(nonnull SYMapLoaderMapPackage*)package fromTask:(nonnull SYTask*)task;

/*!
 @brief Called when progress of SYMapLoader::installMapPackage: method is changed.
 @param maploader The SYMapLoader instance sending the callback.
 @param progress The SYMapLoaderMapPackageInstallProgress containing progress information.
 @param package The SYMapLoaderMapPackage for this operation.
 @param task The original SYTask.
 */
-(void)mapLoader:(nonnull SYMapLoader*)maploader didUpdateMapPackageInstallProgress:(nonnull SYPackageInstallProgress*)progress forPackage:(nonnull SYMapLoaderMapPackage*)package fromTask:(nonnull SYTask*)task;

/*!
 @brief Called when SYMapLoader::getMapGroups method is completed.
 @param mapLoader The SYMapLoader instance sending the callback.
 @param groups The collection of SYMapLoaderMapGroup data.
 @param task The original SYTask.
 */
-(void)mapLoader:(nonnull SYMapLoader*)mapLoader didGetMapGroups:(nonnull NSArray<SYMapLoaderMapGroup*>*)groups fromTask:(nonnull SYTask*)task;

/*!
 @brief Called when SYMapLoader::getMapPackagesForMapGroup: method is completed.
 @param mapLoader The SYMapLoader instance sending the callback.
 @param packages The collection of SYMapLoaderMapPackage data.
 @param task The original SYTask.
 */
-(void)mapLoader:(nonnull SYMapLoader*)mapLoader didGetMapPackagesForMapGroup:(nonnull SYMapLoaderMapGroup*)mapGroup packages:(nonnull NSArray<SYMapLoaderMapPackage*>*)packages fromTask:(nonnull SYTask*)task;

/*!
 @brief Callback to SYMapLoader::loadMapPackages: method. Is called for every SYMapPackage.
 @param mapLoader The SYMapLoader instance sending the callback.
 @param package The SYMapLoaderMapPackage for this operation.
 @param result SYMapLoaderLoadPackageResult result.
 */
-(void)mapLoader:(nonnull SYMapLoader*)mapLoader didLoadMapPackage:(nonnull SYMapLoaderMapPackage*)package withResult:(SYMapLoaderLoadPackageResult)result;

/*!
 @brief Callback to SYMapLoader::unloadMapPackages: method. Is called for every SYMapPackage.
 @param mapLoader The SYMapLoader instance sending the callback.
 @param package The SYMapLoaderMapPackage for this operation.
 @param result SYMapLoaderLoadPackageResult result.
 */
-(void)mapLoader:(nonnull SYMapLoader*)mapLoader didUnloadMapPackage:(nonnull SYMapLoaderMapPackage*)package withResult:(SYMapLoaderLoadPackageResult)result;

/*!
 @brief Callback to SYMapLoader::checkForMapDataUpdate: method.
 @param mapLoader The SYMapLoader instance sending the callback.
 @param packagesToUpdate The set of SYMapLoaderMapPackage with available map update.
 */
-(void)mapLoader:(nonnull SYMapLoader*)mapLoader didCheckForMapUpdateWithAvailableUpdates:(nonnull NSSet<SYMapLoaderMapPackage*>*)packagesToUpdate;

/*!
 @brief Callback to SYMapLoader::updateMapPackages: method.
 @param mapLoader The SYMapLoader instance sending the callback.
 @param updateTasks NSDictionary of created task and their SYMapLoaderMapPackages. Update of one SYMapPackage can create more than one SYTask in case that additional packages are required to be updated.
 */
-(void)mapLoader:(nonnull SYMapLoader*)mapLoader didRequestMapPackagesUpdate:(nonnull NSDictionary<SYTask*,SYMapLoaderMapPackage*>*)updateTasks fromTask:(nonnull SYTask*)task;
@end

/*!
 @brief Provides methods which facilitate usage of offline map data capabilities. Some calls made to SYMapLoader are asynchronous and return results through the SYMapLoaderDelegate protocol.
 */
@interface SYMapLoader : NSObject

/*!
 @brief Current SYMapLoaderDelegate.
 */
@property(nonatomic,weak,nullable) id<SYMapLoaderDelegate> delegate;

/*!
 @brief Get the SYMapLoader singleton instance.
 @return SYMapLoader instance.
 */
+(nonnull SYMapLoader*)sharedMapLoader;

/*!
 @brief SYMapLoader is singleton, use [SYMapLoader sharedMapLoader] to access singleton instance.
 */
-(nonnull instancetype)init __attribute__((unavailable("Use +[SYMapLoader sharedMapLoader] instead.")));
+(nonnull SYMapLoader*)new __attribute__((unavailable("Use +[SYMapLoader sharedMapLoader] instead.")));

/*!
 @brief Requests list of available SYMapGroups.
 @return SYTask for requested operation.
 */
-(nonnull SYTask*)getMapGroups;

/*!
 @brief Requests list of available SYMapPackages.
 @param mapGroup Parent group of map packages. Pass nil to get all available map packages.
 @return SYTask for requested operation.
 */
-(nonnull SYTask*)getMapPackagesForMapGroup:(nullable SYMapLoaderMapGroup*)mapGroup;

/*!
 @brief Requests installation of SYMapPackage.
 @param package Package to be installed.
 @return NSDictionary of created task and their SYMapLoaderMapPackages. Installation of SYMapPackage can create more than one SYTask in case that additional packages are required to be installed.
 */
-(nullable NSDictionary<SYTask*,SYMapLoaderMapPackage*>*)installMapPackage:(nonnull SYMapLoaderMapPackage*)package;

/*!
 @brief Requests uninstallation of SYMapPackage.
 @param package Package to be uninstalled.
 @return NSDictionary of created task and their SYMapLoaderMapPackages. Uninstallation of SYMapPackage can create more than one SYTask in case that additional packages are required to be uninstalled.
 */
-(nullable NSDictionary<SYTask*,SYMapLoaderMapPackage*>*)uninstallMapPackage:(nonnull SYMapLoaderMapPackage*)package;

/*!
 @brief Requests update of SYMapPackages. SYMapPackages which are not included in packages parameter, will be deleted during update.
 Package update progress and completion will be reported by SYMapLoaderDelegate::mapLoader:didUpdateMapPackageInstallProgress:forPackage:fromTask: and SYMapLoaderDelegate::mapLoader:didInstallMapPackage:result:fromTask: methods.
 @param packages Packages to be updated.
 @return SYTask for requested operation.
 */
-(nullable SYTask*)updateMapPackages:(nonnull NSSet<SYMapLoaderMapPackage*>*)packages;

/*!
 @brief Get installed map packages.
 @return Collection of installed SYMapLoaderMapPackage info.
 */
-(nonnull NSArray<SYMapLoaderMapPackage*>*)readInstalledPackages;

/*!
 @brief Load installed map package.
 @param packages A collection of installed SYMapLoaderMapPackage to be loaded.
 */
-(void)loadMapPackages:(nonnull NSArray<SYMapLoaderMapPackage*>*)packages;

/*!
 @brief Unload installed map package.
 @param packages A collection of installed SYMapLoaderMapPackage to be unloaded.
 */
-(void)unloadMapPackages:(nonnull NSArray<SYMapLoaderMapPackage*>*)packages;

/*!
 @brief Requests check if map data update is available.
 Operation result is called via SYMapLoaderDelegate::maploader:didCheckForMapUpdateWithAvailableUpdates:
 @return SYTask for requested operation.
 */
-(nullable SYTask*)checkForMapDataUpdate;

/*!
 @brief Get additional map info.
 */
-(nullable SYMapInfo*)getMapInfo:(nonnull SYCountryIso*)iso;

/*!
 @brief Removes all cached online maps data.
 */
-(void)clearOnlineMapsCache;
@end

#import <UIKit/UIView.h>

/*!
 @brief A UIView subclass used by an application to display a 3D lane assistant.
 */
@interface SYLaneAssistView : UIView
@end

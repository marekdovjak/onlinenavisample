#import <Foundation/NSObject.h>

@class UIColor;

/*!
 @brief Types of position that the SYMapPositionIndicator can use.
 */
typedef NS_ENUM(NSInteger, SYMapPositionIndicatorType)
{
	/*!
	 @brief The latest unprocessed position received from the current vehicle position source.
	 */
	SYMapPositionIndicatorTypeRaw,
	
	/*!
	 @brief The mode in which raw position data is matched to the road network.
	 */
	SYMapPositionIndicatorTypeMapMatched
};

/*!
 @brief Rotation mode that the SYMapPositionIndicator can use.
 */
typedef NS_ENUM(NSInteger, SYMapPositionIndicatorRotation)
{
	/*!
	 @brief Rotation is matched to the road network.
	 */
	SYMapPositionIndicatorRotationMapMatched,
	
	/*!
	 @brief Rotation is matched to the current attitude.
	 */
	SYMapPositionIndicatorRotationAttitude
};

/*!
 @brief Used to provide a visual indication of the user's current position.
 */
@interface SYMapPositionIndicator : NSObject

/*!
 @brief SYMapPositionIndicator type.
 */
@property(nonatomic,assign) SYMapPositionIndicatorType type;

/*!
 @brief SYMapPositionIndicator rotation mode.
 */
@property(nonatomic,assign) SYMapPositionIndicatorRotation rotationMode;

/*!
 @brief Indicates whether the SYMapPositionIndicator is visible.
 */
@property(nonatomic,assign) BOOL visible;

/*!
 @brief Color of the accuracy indicator circle.
 */
@property(nonatomic,strong) UIColor* accuracyIndicatorColor;

/*!
 @brief Indicates whether the SYMapPositionIndicator accuracy indicator (the surrounding circle) is visible.
 */
@property(nonatomic,assign) BOOL accuracyIndicatorVisible;
@end

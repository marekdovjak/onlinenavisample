#import <SygicMaps/SYPlacesObjects.h>

@class SYLocationInfo;

/*!
 @brief Base class representing details about the found data. Each found result can contain additional information, but it does not have to.
 */
@interface SYSearchResultDetail : NSObject
/*!
 @brief The coordinate of SYSearchResultDetail.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* coordinate;
/*!
 @brief The bounding box of the place location.
 */
@property(nonatomic,readonly,nullable) SYGeoBoundingBox* boundingBox;
@end

/*!
 @brief Provides details about the found country.
 */
@interface SYSearchResultDetailCountry : SYSearchResultDetail
@end

/*!
 @brief Provides details about the found postal.
 */
@interface SYSearchResultDetailPostal : SYSearchResultDetail
@end

/*!
 @brief Provides details about the found city.
 */
@interface SYSearchResultDetailCity : SYSearchResultDetail
/*
 @brief Returns true if search result city is a capital city.
 */
@property(nonatomic,readonly) BOOL isCapitalCity;
/*!
 @brief Population of the found city.
 */
@property(nonatomic,readonly) NSUInteger population;
@end

/*!
 @brief Provides details about the found street.
 */
@interface SYSearchResultDetailStreet : SYSearchResultDetail
@end

/*!
 @brief Provides details about the found address point.
 */
@interface SYSearchResultDetailAddressPoint : SYSearchResultDetail
/*!
 @brief Represents the exact position of the entry of the address. Entry can be on different street as the address is.
 */
@property(nonatomic,readonly,nonnull) SYGeoCoordinate* entryCoordinate;
@end

/*!
 @brief Provides details about the found postal address.
 */
@interface SYSearchResultDetailPostalAddress : SYSearchResultDetail
@end

/*!
 @brief Provides details about the found POI.
 */
@interface SYSearchResultDetailPoi : SYSearchResultDetail
/*!
 @brief Represents the exact position of the entry of the POI. Entry can be on different street as the POI is.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* entryCoordinate;
/*!
 @brief Poi name.
 */
@property(nonatomic,readonly,nonnull) NSString* name;
/*!
 @brief Poi group
 */
@property(nonatomic,readonly) SYPoiGroup group;
/*!
 @brief Poi category.
 */
@property(nonatomic,readonly) SYPoiCategory category;
/*!
 @brief The information for the location represented by the POI object.
 */
@property(nonatomic,readonly,nonnull) SYLocationInfo* locationInfo;
@end

/*!
 @brief Provides details about the found POI category.
 */
@interface SYSearchResultDetailPoiCategory : SYSearchResultDetail
/*!
 @brief List of POIs, which are the result of our search and are a part of the result POI category.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYSearchResultDetailPoi*>* pois;
@end

/*!
 @brief Provides details about the found POI category group.
 */
@interface SYSearchResultDetailPoiCategoryGroup : SYSearchResultDetail
/*!
 @brief List of POIs, which are the result of our search and are a part of the result POI group.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYSearchResultDetailPoi*>* pois;
@end


#import <Foundation/NSDate.h>
#import <SygicMaps/SYTypes.h>

@class SYRoute, SYGeoBoundingBox;

/*!
 @brief The severity levels of a traffic event.
 */
typedef NS_ENUM(NSUInteger, SYTrafficSeverity)
{
	SYTrafficSeverityUndefined,
	SYTrafficSeverityNormal,
	SYTrafficSeverityHigh,
	SYTrafficSeverityVeryHigh,
	SYTrafficSeverityBlocking
};

/*!
 @brief The traffic level on route.
 */
typedef NS_ENUM(NSUInteger, SYTrafficLevel)
{
	SYTrafficLevelNone,
	SYTrafficLevelLow,
	SYTrafficLevelMedium,
	SYTrafficLevelHigh
};

/*!
 @brief SYTrafficEvent represents a real-world traffic event such as an accident or road work.
 Not all traffic events will have complete information available, and some information may not be available immediately. If a property returns nil, it should be checked again after some time.
 */
@interface SYTrafficEvent : NSObject

/*!
 @brief Delay in seconds
 */
@property(nonatomic,readonly) NSTimeInterval delay;

/*!
 @brief Distance of the traffic event from the route start, in meters.
 */
@property(nonatomic,readonly) SYDistance distance;

/*!
 @brief The affected length of the traffic event, in meters.
 */
@property(nonatomic,readonly) SYDistance affectedLength;

/*!
 @brief Event unique id
 */
@property(nonatomic,nonnull,readonly) NSString* uniqueId;

/*!
 @brief Indicates the severity of the traffic event, from "Normal" to "Blocking".
 */
@property(nonatomic,readonly) SYTrafficSeverity severity;

/*!
 @brief Area bounding box of the event.
 */
@property(nonatomic,nullable,readonly) SYGeoBoundingBox* affectedArea;

@end

/*!
 @brief Provides information about the current traffic.
 */
@interface SYTrafficInfo : NSObject
/*!
 @brief Time delay on route
 */
@property(nonatomic,readonly) NSTimeInterval delay;

/*!
 @brief Collection of SYTrafficEvent on route
 */
@property(nonatomic,nullable,readonly) NSArray<SYTrafficEvent*>* events;

/*!
 @brief SYTrafficLevel on route
 */
@property(nonatomic,readonly) SYTrafficLevel trafficLevel;
@end

@class SYTraffic;

/*!
 @brief SYTrafficDelegate provids traffic warnings relevant to the current navigation session.
 */
@protocol SYTrafficDelegate <NSObject>
@optional
/*!
 @brief Called when traffic on the current route is changed.
 This method will only be called when SYNavigationManager is navigating a route using a transport mode of SYTransportModeCar.
 @param trafficInfo Traffic info, it is nil if no data is available.
 @param route Updated route
 */
-(void)traffic:(nonnull SYTraffic*)traffic didUpdateTraffic:(nullable SYTrafficInfo*)trafficInfo onRoute:(nullable SYRoute*)route;

/*!
 @brief Called when requestTrafficOnRoute has finished
 */
-(void)trafficDataReady:(nonnull SYTraffic*)traffic onRoute:(nonnull SYRoute*)route;

/*!
 @brief Response to getTrafficDataOnRoute. Contains the actuall traffic data.
 @param trafficInfo Current traffic information, nil if no data is available.
 @param route Updated route
 */
-(void)traffic:(nonnull SYTraffic*)traffic trafficData:(nullable SYTrafficInfo*)trafficInfo onRoute:(nullable SYRoute*)route;
@end

/*!
 @brief Provides traffic warning information for the current navigation session.
 In order to obtain traffic warning information and receieve SYTrafficDelegate callbacks traffic service must be enabled.
 */
@interface SYTraffic : NSObject
@property(nonatomic,weak, nullable) id<SYTrafficDelegate> delegate;
/*!
 @brief Enable or disable traffic service.
 */
@property(nonatomic,assign) BOOL enabled;
+(nonnull SYTraffic*)sharedTraffic;

/*!
 @brief Start receiving didUpdateTraffic callbacks
 Will be started by default if there is an active navigation session and you are in car mode.
 */
-(void)startTrafficWarning;

/*!
 @brief Stop receiving didUpdateTraffic callbacks
 */
-(void)stopTrafficWarning;

/*!
 @brief Request to download all traffic data along the given route
 This method downloads the latest traffic information available along the specified route, so a data connection is required. Once downloaded, the traffic information can be viewed on a map or individual traffic events can be retrieved.
 @param route The route on which to query traffic events.
 */
-(void)requestTrafficOnRoute:(nonnull SYRoute*)route;

/*!
 @brief After recieving TrafficDataReady, you can get additional info about traffic along given route.
 This method retrieves traffic events for a route that have been previously downloaded, for example by calling requestTrafficOnRoute or displaying the traffic on a map.
 @param route The route on which you want to display traffic events.
 */
-(void)getTrafficDataOnRoute:(nonnull SYRoute*)route;

@end



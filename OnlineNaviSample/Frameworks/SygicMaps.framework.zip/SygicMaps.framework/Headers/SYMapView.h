#import <UIKit/UIView.h>
#import <UIKit/UIGestureRecognizer.h>
#import <SygicMaps/SYMapAnimations.h>

@class SYGeoCoordinate, SYGeoBoundingBox, SYMapPositionIndicator, SYTask, SYViewObject, SYAnnotation, SYAnnotationView, SYMapObject, SYMapMarkersCluster;

/*!
 @brief A UIView subclass used by an application to display a map.
 */
@class SYMapView;

/*!
 @brief Available camera rotation modes.
 */
typedef NS_ENUM(NSInteger,SYCameraRotation)
{
	SYCameraRotationFree,
	SYCameraRotationNorthUp,
	SYCameraRotationAttitude,
	SYCameraRotationVehicle
};

/*!
 @brief Available camera movement modes.
 */
typedef NS_ENUM(NSInteger,SYCameraMovement)
{
    /*!
     @brief The camera movement is free.
     */
	SYCameraMovementFree,
    
    /*!
     @brief Camera follows the GPS position.
     */
	SYCameraMovementFollowGpsPosition,
	
	/*!
	 @brief Camera follows the GPS position with autozoom enabled.
	 */
	SYCameraMovementFollowGpsPositionWithAutozoom
};

/*!
 @brief Frames per second limit mode.
 */
typedef NS_ENUM(NSInteger,SYFpsLimitMode)
{
    
/*!
@brief Always try to run at maximum fps.
*/
    SYFpsLimitModePerformance,
	
/*!
@brief Try to achieve smooth camera movement with minimum performance requirements.
*/
	SYFpsLimitModeBalanced
};

/*!
 @brief Result of SYMapView map object add/remove operations.
 */
typedef NS_ENUM(NSInteger,SYMapObjectsResult)
{
    /*!
     @brief Map object was added/removed successfully..
     */
	SYMapObjectsResultSuccess,
    
    /*!
     @brief Map object was added/removed successfully..
     */
	SYMapObjectsResultInvalidValue,
    
    /*!
     @brief Map object model was not initialized.
     */
	SYMapObjectsResultModelNotInitialized,
    
    /*!
     @brief Map object not found.
     */
	SYMapObjectsResultNotFound
};

/*!
 @brief Map display units.
 */
typedef NS_ENUM(NSInteger,SYMapDisplayUnits)
{
    SYMapDisplayUnitsMetric,
    SYMapDisplayUnitsImperial,
    SYMapDisplayUnitsRegional
};

/*!
 @brief Map transform center settings for transitions between SYCameraMovementFree and SYCameraMovementFollowGpsPosition/SYCameraMovementFollowGpsPosition camera movement modes.
 */
struct SYTransformCenterSettings
{
    /*!
     @brief Point at which map movements and animations are centered, when camera movement mode is set to SYCameraMovementFree.
     The transformCenter is specified in relative coordinates in the range {[0,1],[0,1]},with {0,0} representing the lower left corner of the map and {1,1} the upper right corner.
     */
    CGPoint transformCenterFree;
    
    /*!
     @brief Animation curve when transformCenterFree is applied.
     */
    SYMapAnimationCurve animationCurveFree;
    
    /*!
     @brief Animation duration when transformCenterFree is applied.
     */
    NSTimeInterval animationDurationFree;
    
    /*!
     @brief Point at which map movements and animations are centered, when camera movement mode is set to SYCameraMovementFollowGpsPosition or SYCameraMovementFollowGpsPositionWithAutozoom.
     The transformCenter is specified in relative coordinates in the range {[0,1],[0,1]},with {0,0} representing the lower left corner of the map and {1,1} the upper right corner.
     */
    CGPoint transformCenterFollowGps;
    
    /*!
     @brief Animation curve when transformCenterFollowGps is applied.
     */
    SYMapAnimationCurve animationCurveFollowGps;
    
    /*!
     @brief Animation duration when transformCenterFollowGps is applied.
     */
    NSTimeInterval animationDurationFollowGps;
};

typedef struct SYTransformCenterSettings SYTransformCenterSettings;

/*!
 @brief Represents a delegate that offers listeners and callback methods related to visible actions that result from user interaction.
 Methods of this protocol are called on the main queue.
 */
@protocol SYMapViewDelegate <NSObject>
@optional
/*!
 @brief Callback to notify every change on map view's camera position.
 @param mapView Map view camera changes are related to.
 @param geoCenter New camera position.
 @param zoom New camera zoom.
 @param rotation New camera rotation.
 @param tilt New camera tilt.
 */
-(void)mapView:(nonnull SYMapView*)mapView didChangeCameraPosition:(nonnull SYGeoCoordinate*)geoCenter zoom:(CGFloat)zoom rotation:(CGFloat)rotation tilt:(CGFloat)tilt;

/*!
 @brief Callback to notify when camera movement mode has changed.
 */
-(void)mapView:(nonnull SYMapView*)mapView didChangeCameraMovementMode:(SYCameraMovement)mode;

/*!
 @brief Callback to notify when camera rotation mode has changed.
 */
-(void)mapView:(nonnull SYMapView*)mapView didChangeCameraRotationMode:(SYCameraRotation)mode;

/*!
 @brief Callback indicating that SYViewObject map objects have been selected. Available only when SYMapView::mapInteractionEnabled is set to YES.
 */
-(void)mapView:(nonnull SYMapView*)mapView didSelectObjects:(nonnull NSArray<SYViewObject*>*)objects;

/*!
 @brief Returns the view associated with the specified annotation object.
 */
-(nonnull SYAnnotationView*)mapView:(nonnull SYMapView*)mapView viewForAnnotation:(nonnull SYAnnotation*)annotation;

/*!
 @brief Callback to notify map did stop moving.
 */
-(void)mapViewDidStopMoving:(nonnull SYMapView*)mapView;
@end

/*!
 @brief A UIView subclass used by an application to display a map.
 */
@interface SYMapView : UIView <UIGestureRecognizerDelegate>
/*!
 @brief Initialize SYMapView with camera target values.
 */
-(nonnull instancetype)initWithFrame:(CGRect)frame geoCenter:(nonnull SYGeoCoordinate*)geoCenter rotation:(SYAngle)rotation zoom:(CGFloat)zoom tilt:(SYAngle)tilt;

/*!
 @brief SYMapViewDelegate delegate
 */
@property(nonatomic,weak,nullable) id<SYMapViewDelegate> delegate;

/*!
 @brief Enables or disables rendering of the map view.
 */
@property(nonatomic,assign) BOOL renderEnabled;

/*!
 @brief The position indicator.
 */
@property(nonatomic,readonly,nonnull) SYMapPositionIndicator* positionIndicator;

/*!
@brief Enables or disables map gesture interaction for the SYMapView. If this property is set to NO,you can not use ani map gestures and you can implement yours.
 */
@property(nonatomic,assign) BOOL mapInteractionEnabled;

/*!
 @brief Represents the camera movement mode. Take a look at the available SYCameraMovementModes.
 */
@property(nonatomic,assign) SYCameraMovement cameraMovementMode;

/*!
 @brief Represents the camera rotation behaviour. Take a look at the available SYCameraRotationModes.
 */
@property(nonatomic,assign) SYCameraRotation cameraRotationMode;

/*!
 @brief The SYGeoCoordinates corresponding to the current screen position of the transformCenter.
 */
@property(nonatomic,strong,nonnull) SYGeoCoordinate* geoCenter;

/*!
 @brief Current view zoom level.
 The zoom level determines how "close" the map view is to the surface of the Earth. Higher zoom levels give a closer view. Zoom 1 is the view on the earth, zoom 10 is approximately view on city, 15 on street, etc.
 */
@property(nonatomic,assign) CGFloat zoom;

/*!
 @brief The current view rotation,in a range of degrees between [0..360).
 By default,the map is oriented with north toward the top of the map (0 degrees). As the orientation angle increases,the map rotates counter-clockwise so that at 90 degrees.
 */
@property(nonatomic,assign) SYAngle rotation;

/*!
 @brief The SYGeoBoundingBox representing the current screen area of the SYMapView.
 */
@property(nonatomic,strong,nonnull) SYGeoBoundingBox* boundingBox;

/*!
 @brief Current view tilt in degrees <0,80>
 The tilt controls the perspective at which the map is viewed. A value of 0 degrees corresponds to looking straight down at the map from above (2D). As the tilt value is increased,the view shifts to a 3D perspective. 
 
 The tilt of the map may be further constrained at some zoom levels. For example,no tilt is allowed at the lowest zoom levels when the globe is visible. This is to provide a better user experience when interacting with globe,since viewing a "tilted" globe does give any benefit.
 */
@property(nonatomic,assign) SYAngle tilt;

/*!
 @brief Represents the current active skins. 
 */
@property(nonatomic,copy,nonnull) NSArray<NSString*>* activeSkins;

/*!
 @brief The language which the map is set to render.
 It is nil if the display language isn't set and the default language English (en) is being used.
 */
@property(nonatomic,strong,nullable) NSString* displayLanguage;

/*!
 @brief Units which the map is set to render.
 */
@property(nonatomic,assign) SYMapDisplayUnits displayUnits;

/*!
 @brief Annotations are models used to annotate coordinates on the map.
 Implement [SYMapViewDelegate mapView:viewForAnnotation:] to return the annotation view for each annotation.
 */
@property(nonatomic,readonly,nonnull) NSArray<SYAnnotation*> *annotations;

/*!
 @brief YES if map is changing its position, NO otherwise.
 */
@property(nonatomic,readonly) BOOL isMapMoving;

/*!
 @brief YES if any map move gesture is performed on SYMapView, NO otherwise.
 If SYMapView::mapInteractionEnabled is set to NO, property is always NO.
 */
@property(nonatomic,readonly) BOOL isMapGestureInProgress;

/*!
 @brief Converts points from screen coordinates to geographical coordinates.
 */
-(nonnull NSArray<SYGeoCoordinate*>*)geoCoordinatesFromScreenPoints:(nonnull NSArray<NSValue*>*)screenPoints;

/*!
 @brief Enumerate available map skins.
 To set active skins, use SYMapView activeSkins property.
 */
-(nonnull NSArray<NSString*>*) availableSkins;

/*!
 @brief Converts geographical coordinates to screen points stored as [NSValue valueWithCGPoint].
 */
-(nonnull NSArray<NSValue*>*)screenPointsFromGeoCoordinates:(nonnull NSArray<SYGeoCoordinate*>*)geoCoords;

/*!
 @brief Adds a SYMapObject to the SYMapView.
 Valid geo coordinates will produce a valid point,even if the coordinates are not on the screen or are above the visible horizon,as long as the coordinates are not too far from the current map location. 
 @param mapObject SYMapObject to add.
 @return YES if the mapObject was added successfully. Returns NO if the object has already been added (duplicates are not allowed).
 */
-(SYMapObjectsResult)addMapObject:(nonnull SYMapObject*)mapObject;

/*!
 @brief Adds an array of SYMapObjects to the SYMapView.
 @param mapObjects Array of SYMapObject to add.
 @return YES if all mapObjects were added successfully,NO otherwise.
 */
-(SYMapObjectsResult)addMapObjects:(nonnull NSArray<SYMapObject*>*)mapObjects;

/*!
 @brief Removes a SYMapObject from the SYMapView.
 @param mapObject SYMapObject to remove.
 @return YES if the mapObject was removed successfully,NO otherwise.
 */
-(SYMapObjectsResult)removeMapObject:(nonnull SYMapObject*)mapObject;

/*!
 @brief Removes an array of SYMapObjects from the SYMapView.
 @param mapObjects Array of SYMapObject to be removed.
 @return YES if all mapObjects were removed successfully,NO otherwise.
 */
-(SYMapObjectsResult)removeMapObjects:(nonnull NSArray<SYMapObject*>*)mapObjects;

/*!
 @brief Request a NSArray of all SYViewObject objects that are selected at a specified point on the screen.
 @param point Screen point.
 @param completion Completion block.
 @return SYTask instance.
 */
-(nullable SYTask*)objectsAtPoint:(CGPoint)point withCompletion:(nonnull void(^)(NSArray<SYViewObject*>* _Nonnull))completion;

/*!
 @brief Array of all SYMapObject in current SYMapView instance.
 */
-(nonnull NSArray<SYMapObject*>*)allMapObjects;

/*!
 @brief Set target FPS value.
 @param mode SYFpsLimitMode.
 @param limit In case of SYFpsLimitModePerformance mode,limit means target fps value which is always tried to achieve.
 In case of SYFpsLimitModeBalanced,limit means lowest fps value,which is tried to achieve at slow camera movements to save battery life.
 */
-(void)setFpsLimitMode:(SYFpsLimitMode)mode withFpsLimit:(CGFloat)limit;

/*!
 @brief Rotate current view camera by offset in degrees.
 @param angle Camera rotation offset in degrees.
 @param duration Animation duration.
 @param curve Animation curve.
 @param completion Animation completion block.
 @return Animation identifier. SYAnimationNone if animation param is nil or no animation was started.
 */
-(SYAnimationId)rotateView:(SYAngle)angle withDuration:(NSTimeInterval)duration curve:(SYMapAnimationCurve)curve completion:(nullable SYAnimationCompletionBlock)completion;

/*!
 @brief Drag current view camera by offset in screen points.
 @param drag Camera move offset in screen points.
 @param duration Animation duration.
 @param curve Animation curve.
 @param completion Animation completion block.
 @return Animation identifier. SYAnimationNone if animation param is nil or no animation was started.
 */
-(SYAnimationId)dragView:(CGPoint)drag withDuration:(NSTimeInterval)duration curve:(SYMapAnimationCurve)curve completion:(nullable SYAnimationCompletionBlock)completion;

/*!
 @brief Drag current view camera from one screen point to another screen point.
 @param from Screen from point.
 @param to Screen to point.
 @param duration Animation duration.
 @param curve Animation curve.
 @param completion Animation completion block.
 @return Animation identifier. SYAnimationNone if animation param is nil or no animation was started.
 */
-(SYAnimationId)dragViewFrom:(CGPoint)from to:(CGPoint)to withDuration:(NSTimeInterval)duration curve:(SYMapAnimationCurve)curve completion:(nullable SYAnimationCompletionBlock)completion;

/*!
 @brief Zoom current view camera by scale.
 @param scale Zoom scale.
 @param center Screen point to zoom at. Usually represents center of pinch gesture toches. Ignored if SYMapView.cameraMovementMode is not SYCameraMovementFree.
 @param duration Animation duration.
 @param curve Animation curve.
 @param completion Animation completion block.
 @return Animation identifier. SYAnimationNone if animation param is nil or no animation was started.
 */
-(SYAnimationId)zoomView:(CGFloat)scale atPoint:(CGPoint)center withDuration:(NSTimeInterval)duration curve:(SYMapAnimationCurve)curve completion:(nullable SYAnimationCompletionBlock)completion;

/*!
 @brief Transforms the map to fit an arbitrary geo bounding box.
 @param boundingBox SYGeoBoundingBox to show.
 @param edgeInsets Edge insets in relative screen coordinates <0,1>.
 @param duration Animation duration.
 @param curve Animation curve.
 @param completion Animation completion block.
 @return Animation identifier. SYAnimationNone if animation param is nil or no animation was started.
 */
-(SYAnimationId)setViewBoundingBox:(nonnull SYGeoBoundingBox*)boundingBox withEdgeInsets:(UIEdgeInsets)edgeInsets duration:(NSTimeInterval)duration curve:(SYMapAnimationCurve)curve completion:(nullable SYAnimationCompletionBlock)completion;

/*!
 @brief Animate map view properties
 @param animations Animation block containing properties changes. Animable properties are geoCenter, rotation, tilt and zoom.
 @duration Animation duration.
 @param curve Animation curve.
 @param completion Animation completion block.
 @return Animation id.
 */
-(SYAnimationId)animate:(nonnull void(^)(void))animations withDuration:(NSTimeInterval)duration curve:(SYMapAnimationCurve)curve completion:(nullable SYAnimationCompletionBlock)completion;

/*!
 @brief Cancel animation.
 */
-(void)cancelAnimationWithId:(SYAnimationId)animation;

/*!
 @brief Cancel all animations.
 */
-(void)cancelAllAnimations;

/*!
 @brief Set the visibility of the map layer categories to be rendered.
 The layer categories are specified using the SYMapLayerCategory enum.
 @param visible YES to make map layer categories visible, NO to hide.
 @param layerCategories An array of NSNumber objects containing SYMapLayerCategory values.
 */
-(void)setVisibility:(BOOL)visible forMapLayerCategories:(nonnull NSArray<NSNumber*>*)layerCategories;

/*!
 @brief Set map transform center point and animation properties.
 */
-(void)setTransformCenterSettings:(SYTransformCenterSettings)settings withDuration:(NSTimeInterval)duration curve:(SYMapAnimationCurve)curve;

/*!
 @brief Get map transform center settings.
 */
-(SYTransformCenterSettings)transformCenterSettings;

/*!
 @brief Get actual transform center.
 */
-(CGPoint)transformCenter;

/*!
 @brief Used by the delegate to acquire a reusable annotation view, or create a new view for registered class, in lieu of allocating a new one.
 */
-(nullable SYAnnotationView*)dequeueReusableAnnotationViewWithIdentifier:(nonnull NSString*)identifier;

/*!
 @brief Adds the specified SYAnnotation to the SYMapView.
 */
-(void)addAnnotation:(nonnull SYAnnotation*)annotation;

/*!
 @brief Adds an array of SYAnnotation objects to the SYMapView.
 */
-(void)addAnnotations:(nonnull NSArray<SYAnnotation*>*)annotations;

/*!
 @brief Adds an array of SYAnnotation objects to the SYMapView.
 */
-(void)removeAnnotation:(nonnull SYAnnotation*)annotation;

/*!
 @brief Removes an array of SYAnnotation objects from the SYMapView.
 */
-(void)removeAnnotations:(nonnull NSArray<SYAnnotation*>*)annotations;

/*!
 @brief Adds SYMapMarkersCluster to the SYMapView.
 */
-(BOOL)addMapMarkersCluster:(nonnull SYMapMarkersCluster*)markersCluster;

/*!
 @brief Removes SYMapMarkersCluster from the SYMapView.
 */
-(BOOL)removeMapMarkersCluster:(nonnull SYMapMarkersCluster*)markersCluster;

/*!
 @brief Returns all SYMapMarkersClusters in the SYMapView.
 */
-(nonnull NSArray<SYMapMarkersCluster*>*)mapMarkersClusters;
@end

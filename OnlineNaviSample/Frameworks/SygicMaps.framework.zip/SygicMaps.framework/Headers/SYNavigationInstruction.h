#import <SygicMaps/SYTypes.h>

@class SYManeuver;

/*!
 @brief Information about upcoming tunnel.
 */
@interface SYTunnelData : NSObject

/*!
 @brief Provides information whether the position is in tunnel or is not.
 */
@property(nonatomic,readonly) BOOL isInTunnel;

/*!
 @brief Represents remaining distance to the end of tunnel.
 */
@property(nonatomic,readonly) SYDistance remainingTunnelDistance;
@end

/*!
 @brief Instruction provides a verbal description of a maneuver.
 */
@interface SYInstruction : NSObject

/*!
 @brief The next primary maneuver.
 */
@property(nonatomic,readonly,nullable) SYManeuver* primaryManeuver;

/*!
 @brief The next secondary maneuver.
 */
@property(nonatomic,readonly,nullable) SYManeuver* secondaryManeuver;

/*!
 @brief Information about tunnel.
 */
@property(nonatomic,readonly,nullable) SYTunnelData* tunnelData;
@end

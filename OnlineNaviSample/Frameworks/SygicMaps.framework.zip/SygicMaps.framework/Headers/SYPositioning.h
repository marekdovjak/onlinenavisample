#import <SygicMaps/SYTypes.h>

@class SYPositionDataSource;

/*!
 @brief SYPositionLoggingType types.
 */
typedef NS_ENUM(NSUInteger, SYPositionLogging)
{
	/*!
	 No logging.
	 */
	SYPositionLoggingNone,
	
	/*!
	 Logs data source inputs to nmea log file *.nmea located in application's documents directory.
	 */
	SYPositionLoggingNMEA
};

/*!
 @brief Represents WGS84 coordinates with double precision.
 */
@interface SYGeoCoordinate : NSObject <NSCopying,NSCoding>

/*!
 @brief The latitude, as measured in degrees, representing north-south coordinate (y-axis on a map). The latitude must be in the range [-90, 90]. Values outside this range will be clamped.
 */
@property(nonatomic,readonly) double latitude;

/*!
 @brief The longitude, as measured in degrees, representing east-west coordinate (x-axis on a map). The longitude must be in the range [-180, 180].
 */
@property(nonatomic,readonly) double longitude;

/*!
 @brief The altitude of the SYGeoCoordinates measured in meters above sea-level. Geocoordinates with positive altitudes represent points above the plane of the map, while negative altitudes are below the plane of the map. Map objects with these coordinates will be displayed accordingly. Valid values are in the range [-10000.0, 10000.0].
 */
@property(nonatomic,readonly) double altitude;

/*!
 @brief Initializes a SYGeoCoordinates instance with specified latitude and longitude values.
 */
-(nullable instancetype)initWithLatitude:(double)latitude longitude:(double)longitude;

/*!
 @brief Initializes a SYGeoCoordinates instance with specified values for the initial latitude, longitude and altitude.
 */
-(nullable instancetype)initWithLatitude:(double)latitude longitude:(double)longitude altitude:(double)altitude;

/*!
 @brief Calculates air distance to specified SYGeoCoordinate.
 */
-(SYDistance)distanceToGeoCoordinate:(nonnull SYGeoCoordinate*)coordinate;
@end

/*!
 @brief Represents position, speed, and course information as provided by a positioning source for a distinct moment in time.
 */
@interface SYPosition : NSObject
-(nonnull instancetype)initWithCoordinate:(nonnull SYGeoCoordinate*)coordinate latitudeAccuracy:(SYAccuracy)latitudeAccuracy longitudeAccuracy:(SYAccuracy)longitudeAccuracy altitudeAccuracy:(SYAccuracy)altitudeAccuracy speed:(SYSpeed)speed course:(SYAngle)course;

/*!
 @brief The geographical location of the position.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* coordinate;

/*!
 @brief The accuracy of the latitude coordinate, in meters.
 */
@property(nonatomic,readonly) SYAccuracy latitudeAccuracy;

/*!
 @brief The accuracy of the longitude coordinate, in meters.
 */
@property(nonatomic,readonly) SYAccuracy longitudeAccuracy;

/*!
 @brief The accuracy of the altitude, in meters.
 */
@property(nonatomic,readonly) SYAccuracy altitudeAccuracy;

/*!
 @brief The movement speed of the position.
 */
@property(nonatomic,readonly) SYSpeed speed;

/*!
 @brief The course (direction of travel) of the position, in degrees. Valid course values are in the range [0, 360), with 0 degrees representing north and values increasing clockwise.
 */
@property(nonatomic,readonly) SYAngle course;
@end


/*!
 @brief SYRoadType.
 */
typedef NS_ENUM(NSInteger, SYRoadType)
{
    SYRoadTypeNone,
    SYRoadTypeClass0,
    SYRoadTypeClass1,
    SYRoadTypeClass2,
    SYRoadTypeClass3,
    SYRoadTypeClass4,
    SYRoadTypeFerries,
    SYRoadTypeRailway
};


@interface SYPositionInfo : NSObject

/*!
 @brief The geographical location of the position.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* coordinate;

/*!
 @brief Country iso code of the country where the current position is.
 */
@property(nonatomic,readonly,nullable) SYCountryIso* country;

/*!
 @brief Represents the city where the current position is.
 */
@property(nonatomic,readonly,nullable) NSString* city;

/*!
 @brief Represents the road number where the current position is.
 */
@property(nonatomic,readonly,nullable) NSString* roadNumber;

/*!
 @brief Represents the area where the current position is.
 */
@property(nonatomic,readonly,nullable) NSString* area;

/*!
 @brief Represents the street where the current position is.
 */
@property(nonatomic,readonly,nullable) NSString* street;

/*!
 @brief Represents the left number where the current position is.
 */
@property(nonatomic,readonly,nullable) NSString* numberLeft;

/*!
 @brief Represents the right number where the current position is.
 */
@property(nonatomic,readonly,nullable) NSString* numberRight;

/*!
 @brief Represents the road class type of road where the current position is.
 */
@property(nonatomic,readonly) SYRoadType roadType;
@end

/*!
 @brief Represents a bounding box that defines a rectangular area in a geographic coordinate system.
 */
@interface SYGeoBoundingBox : NSObject <NSCopying,NSCoding>

/*!
 @brief The SYGeoCoordinates representing the top-left corner of the SYGeoBoundingBox.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* bottomLeft;

/*!
 @brief The SYGeoCoordinates representing the bottom-right corner of the SYGeoBoundingBox.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* topRight;

/*!
 @brief Initializes a SYGeoBoundingBox instance with specified top-left and bottom-right SYGeoCoordinates.
 */
-(nonnull instancetype)initWithBottomLeft:(nonnull SYGeoCoordinate*)bottomLeft topRight:(nonnull SYGeoCoordinate*)topRight;

/*!
 Computes intersection of this SYGeoBoundingBox and the specified SYGeoBoundingBox. Returns nil if interseciton is empty.
 */
-(nullable SYGeoBoundingBox*)intersectionWithGeoBoundingBox:(nonnull SYGeoBoundingBox*)boundingBox;

/*!
 Computes union of this SYGeoBoundingBox and the specified SYGeoBoundingBox.
 */
-(nullable SYGeoBoundingBox*)unionWithGeoBoundingBox:(nonnull SYGeoBoundingBox*)boundingBox;

/*!
 Computes scale of this SYGeoBoundingBox with the specified scale.
 */
-(nullable SYGeoBoundingBox*)scale:(CGFloat)scale;

/*!
 Computes offset of this SYGeoBoundingBox with the specified SYGeoCoordinate.
 */
-(nullable SYGeoBoundingBox*)offsetWithGeoCoordinate:(nonnull SYGeoCoordinate*)coordinate;

/*!
 Determines whether the specified SYGeoCoordinate is contained within this SYGeoBoundingBox.
 */
-(BOOL)containsGeoCoordinate:(nonnull SYGeoCoordinate*)coordinate;

/*!
 Determines whether the specified SYGeoBoundingBox is covered entirely by this SYGeoBoundingBox.
 */
-(BOOL)containsGeoBoundingBox:(nonnull SYGeoBoundingBox*)boundingBox;
@end

/*!
 @brief Manages positioning services for the Sygic SDK.
 */
@class SYPositioning;

@protocol SYPositioningDelegate <NSObject>
@optional

/*!
 @brief Method which indicates that a new position update is available.
 */
-(void)positioning:(nonnull SYPositioning*)positioning didUpdatePosition:(nonnull SYPosition*)position;
@end

/*!
 @brief Manages positioning services for the Sygic SDK. Use the startUpdatingPosition method to begin tracking position, and stopUpdatingPosition to stop.
 */
@interface SYPositioning : NSObject

/*!
 @brief SYPositioning delegate.
 */
@property(nonatomic,weak,nullable) id<SYPositioningDelegate> delegate;

/*!
 @brief The last known SYPosition.
 */
@property(nonatomic,readonly,nullable) SYPosition* lastKnownLocation;

/*!
 @brief The current provider of raw position data for the positioning manager.
 If positioning is started with a nil dataSource, a default instance of SYDevicePositionSource is created and installed
 */
@property(nonatomic,strong,nullable) SYPositionDataSource* dataSource;

/*!
 @brief Configures position update logging.
 */
@property(nonatomic,assign) SYPositionLogging logType;

/*!
 @brief Returns the SYPositioning singleton instance.
 */
+(nonnull SYPositioning*)sharedPositioning;

/*!
 @brief SYPositioning is singleton, use [SYPositioning sharedPositioning] to access singleton instance.
 */
-(nonnull instancetype)init __attribute__((unavailable("Use +[SYPositioning sharedPositioning] instead.")));
+(nonnull SYPositioning*)new __attribute__((unavailable("Use +[SYPositioning sharedPositioning] instead.")));

/*!
 @brief Start updating position.
 */
-(void)startUpdatingPosition;

/*!
 @brief Stop updating position.
 */
-(void)stopUpdatingPosition;
@end

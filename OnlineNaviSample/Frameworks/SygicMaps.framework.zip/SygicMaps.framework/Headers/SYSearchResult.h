#import <Foundation/NSValue.h>
#import <SygicMaps/SYPlacesObjects.h>

typedef NS_ENUM(NSUInteger, SYSearchResultType)
{
    /*!
     @brief No search result type.
     */
	SYSearchResultTypeNone,
    
    /*!
     @brief Search provides a result from map data.
     */
    SYSearchResultTypeMap,
    
    /*!
     @brief Search provides a coordinate result.
     */
	SYSearchResultTypeCoordinate,
	
    /*!
     @brief Search provides a result from the searched history.
     */
	SYSearchResultTypeHistory,
    
    /*!
     @brief Search provides a result from saved favorites.
     */
	SYSearchResultTypeFavorite,
    
    /*!
     @brief Search provides a result from the contants.
     */
	SYSearchResultTypeContact,
	
	/*!
	 @brief Search provides a result from the custom poi.
	 */
	SYSearchResultTypeCustomPoi
};

/*!
 @brief Class with informations about search result label with matched highlights.
 */
@interface SYSearchResultLabel : NSObject
@property(nonatomic,copy,nonnull) NSString* value;
/*!
 @brief Set of [NSValue valueWithRange:] highlights.
 */
@property(nonatomic,strong,nonnull) NSSet<NSValue*>* highlights;
@end

/*!
 @brief Collection of search result labels.
 */
@interface SYMapSearchResultLabels : NSObject

/*!
 @brief Country search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* country;

/*!
 @brief Postal search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* postal;

/*!
 @brief City search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* city;

/*!
 @brief Street search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* street;

/*!
 @brief Left number search result label. If Left and Right number are nonempty and equal - it is nearest address point
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* leftNumber;

/*!
 @brief Right number search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* rightNumber;

/*!
 @brief Built Up area search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* builtUpArea;

/*!
 @brief Address point search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* addressPoint;

/*!
 @brief Postal address search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* postalAddress;

/*!
 @brief POI category search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* poiCategory;

/*!
 @brief POI category group search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* poiCategoryGroup;

/*!
 @brief POI search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* poi;
@end

/*!
 @brief Base class for all search results.
 */
@interface SYSearchResult : NSObject
/*!
 @brief Object type of the result. Check the all available SYSearchResultType for more info.
 */
@property(nonatomic,readonly) SYSearchResultType type;
/*!
 @brief Searched position. This is needed to get the most relevant results.
 */
@property(nonatomic,readonly,nullable) SYGeoCoordinate* coordinate;
@end

/*!
 @brief SYMapSearchResult types
 */
typedef NS_ENUM(NSUInteger, SYMapSearchResultType)
{
	SYMapSearchResultTypeCountry,
	SYMapSearchResultTypePostal,
	SYMapSearchResultTypeCity,
	SYMapSearchResultTypeStreet,
	SYMapSearchResultTypeAddressPoint,
	SYMapSearchResultTypePostalAddress,
	SYMapSearchResultTypePoiCategoryGroup,
	SYMapSearchResultTypePoiCategory,
	SYMapSearchResultTypePoi
};

/*!
 @brief Represents the result of a geocode request.
 The data of a geocode result is represented by an instance of SYSearchResultDetail, accessed through the detail property.
 */
@interface SYMapSearchResult : SYSearchResult
/*!
 @brief Result type.
 */
@property(nonatomic,readonly) SYMapSearchResultType mapResultType;
/*!
 @brief Search result label with matched highlights.
 */
@property(nonatomic,nonnull,readonly) SYMapSearchResultLabels* resultLabels;
/*!
 @brief SYMapSearchResult country iso code.
 */
@property(nonatomic,readonly,nonnull) SYCountryIso* country;
/*!
 @brief Map subregion id.
 */
@property(nonatomic,readonly,nullable) NSString* subregionId;
@end

/*!
 @brief Represents the poi group result of a geocode request.
 */
@interface SYMapSearchResultPoiGroup : SYMapSearchResult
@property(nonatomic,readonly) SYPoiGroup group;
@end

/*!
 @brief Represents the poi category result of a geocode request.
 */
@interface SYMapSearchResultPoiCategory : SYMapSearchResultPoiGroup
@property(nonatomic,readonly) SYPoiCategory category;
@end

/*!
 @brief Represents the poi result of a geocode request.
 */
@interface SYMapSearchResultPoi : SYMapSearchResultPoiCategory
@end

/*!
 @brief Represents the poi category result of a geocode request.
 This is an exact coordinate result, when you search query is longitude and latitude.
 */
@interface SYCoordinateSearchResult : SYSearchResult
@property(nonatomic,strong,nonnull,readonly) NSString* name;
@end

/*!
 @brief Collection of search result labels.
 */
@interface SYCustomSearchResultLabels : NSObject
/*!
 @brief Title search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* title;

/*!
 @brief Secondary search result label.
 */
@property(nonatomic,readonly,nullable) SYSearchResultLabel* secondaryTitle;
@end

/*!
 @brief Represents the result of a history data search.
 */
@interface SYCustomSearchResult : SYSearchResult
/*!
 @brief Search result label with matched highlights.
 */
@property(nonatomic,nonnull,readonly) SYCustomSearchResultLabels* resultLabels;
/*!
 @brief Custom application data.
 */
@property (nonatomic,readonly,nullable) NSObject* payload;
@end

/*!
 @brief Represents the result of a history data search.
 */
@interface SYHistorySearchResult : SYCustomSearchResult
/*!
 @brief Poi category.
 */
@property(nonatomic,readonly) SYPoiCategory poiCategory;

/*!
 @brief Original SYSearchHistory timestamp.
 */
@property(nonatomic,readonly,nonnull) NSDate* timestamp;
@end

/*!
 @brief Represents the result of a contact data search.
 */
@interface SYContactSearchResult : SYCustomSearchResult
@end

/*!
 @brief Represents the result of a favorite data search.
 */
@interface SYFavoriteSearchResult : SYCustomSearchResult
@end

/*!
 @brief Represents the result of a custom poi data search.
 */
@interface SYCustomPoiSearchResult : SYCustomSearchResult
@end

#import <Foundation/NSObject.h>

@class NSString;

/*!
 @brief Context initialization result.
 */
typedef NS_ENUM(NSInteger, SYContexInitResult)
{
    /*!
     @brief Initialization is succcessful.
     */
	SYContexInitResultSuccess,

    /*!
     @brief You have entered an invalid API key.
     */
	SYContexInitResultInvalidAppKey,

    /*!
     @brief API key verification process has failed.
     */
    SYContexInitResultAppKeyVerificationFailed,

    /*!
     @brief Unspecified runtime error.
     */
    SYContexInitResultRuntimeError
};

/*!
 @brief Use this interface to set mandatory authentication credentials
 You have to set authentication credentials (Api key and App Secret code) in order to use the APIs contained within this SDK. Some APIs may appear to work without valid credentials but they may stop functioning in the near future when server side configurations change, so please obtain and use valid credentials.
 */
@interface SYContext : NSObject

/*!
 @brief Initializes Sygic SDK, must be called before any other sdk calls
 @param appKey Application Key
 @param appSecret Application Secret code
 @param completion Initialization completion block
 Sets the mandatory Sygic Authentication Credentials and License Key.

 These credentials MUST be set once before attempting to use any other APIs in the Sygic SDK. You may only call this method once. It is recommended to call this method in [UIApplicationDelegate didFinishLaunchingWithOptions].


 */
+ (void)initWithAppKey:(nonnull NSString*)appKey appSecret:(nonnull NSString*)appSecret completion:(nullable void(^)(SYContexInitResult result))completion;

/*!
 @brief Terminates Sygic SDK.
 */
+ (void)terminate;

/*!
 @brief Check if Sygic SDK is initialized.
 @return YES if Sygic SDK is initialized, otherwise NO. If NO is returned then the Sygic SDK is not ready to handle any service.
 */
+ (BOOL)isInitialized;

/*!
 SDK version in format MAJOR.MINOR.PATCH.
 */
+(nonnull NSString*)sdkVersion;
@end

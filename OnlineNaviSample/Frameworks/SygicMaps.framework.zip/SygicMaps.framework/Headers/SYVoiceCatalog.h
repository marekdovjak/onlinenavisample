#import <Foundation/NSString.h>

@class SYPackageInstallProgress, SYTask;


/*!
 @brief Gender of the VoicePackage
 */
typedef NS_ENUM(NSInteger, SYVoicePackageGender)
{
    /*!
     @brief VoicePackage male voice.
     */
	SYVoicePackageGenderMale,
    
    /*!
     @brief VoicePackage female voice.
     */
	SYVoicePackageGenderFemale,
    
    /*!
     @brief Unknown voice gender.
     */
	SYVoicePackageGenderUnknown
};

/*!
 @brief Current status of the VoicePackage.
 */
typedef NS_ENUM(NSInteger, SYVoicePackageStatus)
{
	/*!
	 @brief Package is not installed.
	 */
	SYVoicePackageStatusNotInstalled,
	
	/*!
	 @brief Package is installed.
	 */
	SYVoicePackageStatusInstalled,
	
	/*!
	 @brief Package is a system voice.
	 */
	SYVoicePackageStatusSystemVoice,
	
	/*!
	 @brief Package is currently in installation process.
	 */
	SYVoicePackageStatusInstalling,
	
	/*!
	 @brief Package is in uninstalling process.
	 */	
	SYVoicePackageStatusUninstalling,
};

/*!
 @brief Return information about voice packages. Used in SYVoiceCatalog.
 */
@interface SYVoicePackage : NSObject
/*!
 @brief Name of the voice package localized to the package locale, nil if not available.
 */
@property(nonatomic,nonnull,readonly) NSString* name;

/*!
 @brief Language of the voice package, nil if it is not available.
 */
@property(nonatomic,nonnull,readonly) NSString* language;

/*!
 @brief Unique id used to identify SYVoicePackage.
 */
@property(nonatomic,nonnull,readonly) NSString* packageId;

/*!
 @brief Voice package gender.
 */
@property(nonatomic,readonly) SYVoicePackageGender gender;

/*!
 @brief Current installation status.
 */
@property(nonatomic,readonly) SYVoicePackageStatus status;

/*!
 @brief Size in bytes the SYVoicePackage will take up on disk.
 */
@property(nonatomic,readonly) NSUInteger sizeOnDisk;
@end

/*!
 @brief Manager of voice packages for guided navigation and warnings.
 Can be used to install, uninstall or select current voice packages on the device.
 */
@class SYVoiceCatalog;

/*!
 @brief Provides various callback methods for requests made in SYVoiceCatalog class.
 */
@protocol SYVoiceCatalogDelegate<NSObject>
@optional
/*!
 @brief Called when SYVoiceCatalog::installMapPackage: method is completed. This method will be called whether the installation succeeds, fails or is cancelled.
 @param voiceCatalog The SYVoiceCatalog instance sending the callback.
 @param package The SYVoicePackage for this operation.
 @param task The original SYTask with status information.
 */
-(void)voiceCatalog:(nonnull SYVoiceCatalog*)voiceCatalog didInstallVoicePackage:(nonnull SYVoicePackage*)package fromTask:(nonnull SYTask*)task;

/*!
 @brief Called when SYVoiceCatalog::uninstallMapPackage: method is completed.
 @param voiceCatalog The SYVoiceCatalog instance sending the callback.
 @param package The SYVoicePackage for this operation.
 @param task The original SYTask with status information.
 */
-(void)voiceCatalog:(nonnull SYVoiceCatalog*)voiceCatalog didUninstallVoicePackage:(nonnull SYVoicePackage*)package fromTask:(nonnull SYTask*)task;

/*!
 @brief Called when progress of SYVoiceCatalog::installMapPackage: method is changed.
 @param voiceCatalog The SYVoiceCatalog instance sending the callback.
 @param progress The SYVoicePackageInstallProgress containing progress information.
 @param package The SYVoicePackage for this operation.
 @param task The original SYTask.
 */
-(void)voiceCatalog:(nonnull SYVoiceCatalog*)voiceCatalog didUpdateVoicePackageInstallProgress:(nonnull SYPackageInstallProgress*)progress forPackage:(nonnull SYVoicePackage*)package fromTask:(nonnull SYTask*)task;

@end

/*!
 @brief Manager of voice packages for guided navigation and warnings.
 Can be used to install, uninstall or select current voice packages on the device. 
 */
@interface SYVoiceCatalog : NSObject

/*!
 @brief Current SYVoiceCatalogDelegate.
 */
@property(nonatomic,assign,nullable) id<SYVoiceCatalogDelegate> delegate;

/*!
 @brief Returns SYVoiceCatalog singleton instance
 */
+(nonnull SYVoiceCatalog*)sharedVoiceCatalog;

/*!
 @brief SYAudioManager is singleton, use [SYAudioManager sharedAudioManager] to access singleton instance.
 */
-(nonnull instancetype)init __attribute__((unavailable("Use +[SYVoiceCatalog sharedVoiceCatalog] instead.")));
+(nonnull SYVoiceCatalog*)new __attribute__((unavailable("Use +[SYVoiceCatalog sharedVoiceCatalog] instead.")));

/*!
 @brief Requests collection of available SYVoicePackage. Collection includes installed voice packages
 and packages available to install from server. There no voice packages installed by default, you have to download them. There are just system supported TTS voices.
 @param completion Completion block containing NSArray of available voice packages. 
 @return SYTask for requested operation.
 */
-(nullable SYTask*)getAvailableVoicePackagesWithCompletion:(nonnull void(^)(SYTask* _Nonnull, NSArray<SYVoicePackage*>* _Nonnull))completion;

/*!
 @brief Gets collection of currently installed voice packages and system voices.
 @param completion Completion block containing NSArray of installed voice packages.
 @return Array of currently installed voice packages and system voices.
 */
-(nullable SYTask*)getInstalledPackagesWithCompletion:(nonnull void(^)(SYTask* _Nonnull, NSArray<SYVoicePackage*>* _Nonnull))completion;

/*!
 @brief Downloads and installs a SYVoicePackage to the device.
 Requests installation of SYVoicePackage.
 @param package Package to be installed.
 @return SYTask for requested operation.
 */
-(nullable SYTask*)installVoicePackage:(nonnull SYVoicePackage*)package;

/*!
 @brief Delete a particular SYVoicePackage from the device.
 Requests uninstallation of SYVoicePackage.
 @param package Package to be uninstalled.
 @return SYTask for requested operation.
 */
-(nullable SYTask*)uninstallVoicePackage:(nonnull SYVoicePackage*)package;

/*!
 @brief Sets voice used for voice guided navigation and warnings.
 @param voice SYVoicePackage to be used.
 */
-(void)setCurrentVoice:(nonnull SYVoicePackage*)voice;

/*!
 @brief Play sample of selected voice package.
 Adds sample to SYAudioManager play queue. To play sample immediately, stop SYAudioManager queue by calling [SYAudioManager stopOutputAndClearQueue].
 @param voice SYVoicePackage to be used.
 */
-(void)playSample:(nonnull SYVoicePackage*)voice;
@end

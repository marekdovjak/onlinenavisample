#import <Foundation/NSDate.h>
#import <SygicMaps/SYTypes.h>
#import <SygicMaps/SYRoutingOptions.h>

@class SYPositionInfo, SYSpeedLimit, SYInstruction, SYSignpost, SYRadar, SYRailwayCrossing, SYSharpCurve, SYAlternativeRoute, SYHighwayExit, SYPoiOnRoute,
    SYPoiInfo, SYOnRouteInfo, SYLanesInformation, SYWarning, SYTrafficInfo, SYWaypoint, SYWarningSettings, SYRoute;

/*!
 @brief SYNavigation is a class that provides guidance advice and information along a route.
 */
@class SYNavigation;

/*!
 @brief Receives event callbacks containing information about the current navigation session
 */
@protocol SYNavigationDelegate <NSObject>
@optional

/*!
 @brief Called when current positionInfo has changed.
 @param positionInfo Current position.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdatePositionInfo:(nullable SYPositionInfo*)positionInfo;

/*!
 @brief Called when a speed limit warning has changed.
 @param limit Current speed limit.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateSpeedLimit:(nullable SYSpeedLimit*)limit;

/*!
 @brief Called when current instruction has changed.
 @param instruction Current instruction.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateDirection:(nullable SYInstruction*)instruction;

/*!
 @brief Called when current singpostinfo is changed.
 @param signpostInfo Array of signposts.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateSignpost:(nullable NSArray<SYSignpost*>*)signpostInfo;

/*!
 @brief Called when current radar has changed.
 @param radarInfo Current radar. Nil if no radar is available.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateRadar:(nullable SYRadar*)radarInfo;

/*!
 @brief Called when current route railway crossing has changed.
 @param railwayInfo Current railway crossing. Nil if no crossing is ahead on route.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateRailwayCrossing:(nullable SYRailwayCrossing*)railwayInfo;

/*!
 @brief Called when danger turn is ahead on current route.
 @param sharpCurve Curve info. Nil if no data is available.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateSharpCurve:(nullable SYSharpCurve*)sharpCurve;

/*!
 @brief Called when turn-by-turn navigation waipoint is passed.
 @param index Waypoint index, as passed in viapoints in [SYRouting computeRoute:from:to:via]
 */
-(void)navigation:(nonnull SYNavigation*)navigation didPassWaypointWithIndex:(NSUInteger)index;

/*!
 @brief Called when turn-by-turn navigation destination is reached.
 */
-(void)navigationManagerDidReachFinish:(nonnull SYNavigation*)navigation;

/*!
 @brief Called when better route is found.
 @param alterRoute Better Route info. Nil if no data is available.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didFindBetterRoute:(nullable SYAlternativeRoute*)alterRoute;

/*!
 @brief Called when hihgway exit info has changed. Event does not fire when route is calculated.
 @param highwayExit Highway exit info. Nil if no data is available.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateHighwayExit:(nullable NSArray<SYHighwayExit*>*)highwayExit;

/*!
 @brief Called when current navigation route is changed or removed.
 @param route Updated route. Nil if navigation has been stopped.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateRoute:(nullable SYRoute*)route;

/*!
 @brief Called when all radars along the route has been computed as response to call getRadarsOnRoute.
 @param radars All radars on route.
 @param route Analyzed route.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateRadars:(nullable NSArray<SYRadar*>*)radars onRoute:(nullable SYRoute*)route;

/*!
 @brief Called when pois on current navigation route have changed.
 @param pois All reachable pois along the route.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdatePoisOnRoute:(nullable NSArray<SYPoiOnRoute*>*)pois;

/*!
 @brief Called when pois near vehicle have changed.
 @param pois All pois in area near vehicle.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdatePois:(nullable NSArray<SYPoiInfo*>*)pois;

/*!
 @brief Called when transport mode has changed.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateTransportMode:(SYTransportMode)mode;

/*!
 @brief Called when position on current navigation route has changed.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateOnRouteInfo:(nullable SYOnRouteInfo*)info;

/*!
 @brief Called when lane information on current navigation route has changed.
 */
-(void)navigation:(nonnull SYNavigation*)navigation didUpdateLanesInformation:(nullable SYLanesInformation*)lanesInfo;
@end

/*!
 @brief Delegate to handle Audio feedback.
 */
@protocol SYNavigationAudioFeedbackDelegate <NSObject>
@optional
/*!
 @brief Called when navigation manager has warning audio feedback is ready to play.
 @param warning Warning data for audio feedback.
 @return YES to play the audio feedback. NO to prevent playing the audio feedback.
 */
-(BOOL)navigation:(nonnull SYNavigation*)navigation shouldPlayWarningAudioFeedback:(nonnull SYWarning*)warning;

/*!
 @brief Called when speed limit warning audio feedback is ready to play.
 @param speedLimit Speed limit data for audio feedback.
 @return YES to play the audio feedback. NO to prevent playing the audio feedback.
 */
-(BOOL)navigation:(nonnull SYNavigation*)navigation shouldPlaySpeedLimitAudioFeedback:(nonnull SYSpeedLimit*)speedLimit;

/*!
 @brief Called when a better route audio feedback is ready to play.
 @param route Route data.
 @return YES to play the audio feedback. NO to prevent playing the audio feedback.
 */
-(BOOL)navigation:(nonnull SYNavigation*)navigation shouldPlayBetterRouteAudioFeedback:(nonnull SYAlternativeRoute*)route;

/*!
 @brief Called when treffic change audio feedback is ready to play.
 @param traffic Traffic data.
 @return YES to play the audio feedback. NO to prevent playing the audio feedback.
 */
-(BOOL)navigation:(nonnull SYNavigation*)navigation shouldPlayTrafficAudioFeedback:(nonnull SYTrafficInfo*)traffic;

/*!
 @brief Called when navigation instruction audio feedback is ready to play.
 @param instruction Instruction data.
 @return YES to play the audio feedback. NO to prevent playing the audio feedback.
 */
-(BOOL)navigation:(nonnull SYNavigation*)navigation shouldPlayInstructionAudioFeedback:(nonnull SYInstruction*)instruction;
@end

/*!
 @brief Navigation notification types.
 */
typedef NS_ENUM(NSInteger, SYNavigationNotification)
{
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdatePositionInfo:].
	 */
	SYNavigationNotificationPositionInfo,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateDirection:].
	 */
	SYNavigationNotificationDirections,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateSignpost:].
	 */
	SYNavigationNotificationSignpost,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateRadar:].
	 */
	SYNavigationNotificationRadar,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateRailwayCrossing:].
	 */
	SYNavigationNotificationRailwayCrossing,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateSharpCurve:].
	 */
	SYNavigationNotificationSharpCurve,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didPassWaypoint:].
	 */
	SYNavigationNotificationWaypointPass,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateLanesInformation:].
	 */
	SYNavigationNotificationLanesInformation,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdatePoisOnRoute:].
	 */
	SYNavigationNotificationPoiOnRoute,
	/*!
	 Option to activate [SYNavigationAudioFeedbackDelegate navigation:shouldPlayInstructionAudioFeedback:].
	 */
	SYNavigationNotificationAudioInstructions,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateHighwayExit:].
	 */
	SYNavigationNotificationHighwayExit,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateOnRouteInfo:].
	 */
	SYNavigationNotificationRouteInfo,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdatePois:].
	 */
	SYNavigationNotificationPois,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didFindBetterRoute:].
	 */
	SYNavigationNotificationBetterRotue,
	/*!
	 Option to activate [SYNavigationDelegate navigation:didUpdateSpeedLimit:].
	 */
	SYNavigationNotificationSpeedLimit
};

/*!
 @brief SYNavigation is a class that provides guidance advice and information along a route.
 */
@interface SYNavigation : NSObject

/*!
 @brief Receives event callbacks containing information about the current navigation session
 */
@property(nonatomic,weak,nullable) id<SYNavigationDelegate> delegate;

/*!
 @brief Delegate to handle audio feedback.
 */
@property(nonatomic,weak,nullable) id<SYNavigationAudioFeedbackDelegate> audioFeedbackDelegate;

/*!
 @brief Get current navigation progress.
 @return Progress in interval <0,1> based on travelled and total route distance.
 */
@property(nonatomic,readonly) CGFloat navigationProgress;

/*!
 @brief Returns the distance from current position to the end of route in meters.
 */
@property(nonatomic,readonly) SYDistance remainingDistance;

/*!
 @brief Estimated time to current route's destination.
 The time interval returned includes delays due to traffic etc.
 */
@property(nonatomic,readonly) NSTimeInterval remainingTime;

/*!
 @brief
 The time interval returned includes delays due to traffic etc.
 */
@property(nonatomic,readonly, nullable) NSArray<SYWaypoint*>* waypoints;

/*!
 @brief Warning settings
 */
@property(nonatomic,readonly,nonnull) SYWarningSettings* settings;

/*!
 @brief Controls whether navigation is paused when the application is sent to the background.
 The current [SYPositioning dataSource] must support background position updates in order to navigate in the background.
 */
@property(nonatomic,assign) BOOL backgroundNavigationEnabled;

/*!
 @brief NSSet of SYNavigationNotification values stored with [NSNumber numberWithInteger:].
 Turns on or off SYNavigationDelegate and SYNavigationAudioFeedbackDelegate analyzers and related informations on map.
 By default, all notifications are active.
 */
@property(nonatomic,strong,nonnull) NSSet<NSNumber*>* activeNotifications;

/*!
 @brief Returns SYNavigation singleton instance
 */
+(nonnull SYNavigation*)sharedNavigation;

/*!
 @brief SYNavigation is singleton, use [SYNavigation sharedNavigation] to access singleton instance.
 */
-(nonnull instancetype)init __attribute__((unavailable("Use +[SYNavigation sharedNavigation] instead.")));
+(nonnull SYNavigation*)new __attribute__((unavailable("Use +[SYNavigation sharedNavigation] instead.")));

/*!
 @brief Starts a turn-by-turn navigation session using the specified route.
 */
-(void)startNavigationWithRoute:(nullable SYRoute*)route;

/*!
 @brief Stops the current navigation started via startNavigationWithRoute.
 */
-(void)stopNavigation;

/*!
 @brief Return yes, if you are currently in navigation mode.
 */
-(BOOL)isNavigating;

/*!
 @brief Get actuall radars and speed cameras on your route.
 */
-(void)getRadarsOnRoute:(nullable SYRoute*)route;

/*!
 @brief Replays last instruction audio feedback during navigation.
 */
-(void)replayLastInstructionAudioFeedback;
@end


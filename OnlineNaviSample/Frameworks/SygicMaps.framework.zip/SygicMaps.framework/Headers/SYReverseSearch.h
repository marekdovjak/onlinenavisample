#import <Foundation/NSObject.h>

@class NSArray, SYGeoCoordinate, SYReverseSearchResult;

/*!
 @brief Class providing reverse search functions for location data.
 */
@interface SYReverseSearch : NSObject
/*!
 @brief Invokes an asynchronous request to match a location on the world map. SYSearchResults is returned in SYReverseSearchDelegate::search:didFinishReverseSearchingForCoordinate:withResults: delegate function.
 @param coordinate Object representing the location used to search for results on map
 */
-(void)reverseSearchWithCoordinate:(nonnull SYGeoCoordinate*)coordinate withCompletion:(nonnull void(^)(NSArray<SYReverseSearchResult*>* _Nonnull results))completion;

@end


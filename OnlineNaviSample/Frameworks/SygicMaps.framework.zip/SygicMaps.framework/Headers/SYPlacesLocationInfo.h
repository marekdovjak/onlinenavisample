#import <Foundation/NSObject.h>

@class NSArray;

/*!
 @brief Information fields in SYLocationInfo class.
 */
typedef NS_ENUM(NSInteger, SYLocationInfoField)
{	
	SYLocationInfoFieldName,
	SYLocationInfoFieldAltName,
	SYLocationInfoFieldAddress,
	SYLocationInfoFieldPhone,
	SYLocationInfoFieldMail,
	SYLocationInfoFieldUrl,
	SYLocationInfoFieldFax,
	SYLocationInfoFieldImage,
	SYLocationInfoFieldShortDesc,
	SYLocationInfoFieldLongDesc,
	SYLocationInfoFieldSubType,
	SYLocationInfoFieldOpenHours,
	SYLocationInfoFieldCosts,
	SYLocationInfoFieldBookAdvis,
	SYLocationInfoFieldCreditCards,
	SYLocationInfoFieldBrandNames,
	SYLocationInfoFieldNearTrain,
	SYLocationInfoFieldRoomCount,
	SYLocationInfoFieldDecor,
	SYLocationInfoFieldBreakfast,
	SYLocationInfoFieldTakeaways,
	SYLocationInfoFieldDisabledAccess,
	SYLocationInfoFieldHomeDelivery,
	SYLocationInfoFieldConferences,
	SYLocationInfoFieldCheckInOut,
	SYLocationInfoFieldAccommodationType,
	SYLocationInfoFieldHotelServices,
	SYLocationInfoFieldSpecialFeatures,
	SYLocationInfoFieldSeasonDate,
	SYLocationInfoFieldRelevantPOIS,
	SYLocationInfoFieldComments,
	SYLocationInfoFieldRating,
	SYLocationInfoFieldNonhotelCosts,
	SYLocationInfoFieldStreet,
	SYLocationInfoFieldPostal,
	SYLocationInfoFieldHouseNum,
	SYLocationInfoFieldCity,
	SYLocationInfoFieldWikiDescription,
	SYLocationInfoFieldGPS
};

/*!
 @brief Contains information about a real-world location.
 The types of information available are given by the SYLocationInfoField enum.
 */
@interface SYLocationInfo : NSObject <NSCoding>

/*!
 @brief Retrieves the value of the specified SYLocationInfoField for the SYLocationInfo object.
 @param field NMALocationInfoField to get the field value for.
 @return The NSArray with NSString values for the specified LocationInfoField if available, otherwise nil.
 */
-(nullable NSArray<NSString*>*)valuesForField:(SYLocationInfoField)field;
@end

#import <SygicMaps/SYNavigationWarnings.h>
#import <SygicMaps/SYViewObjects.h>

/*!
 @brief Available POI categories
 */
typedef NS_ENUM(NSInteger, SYPoiCategory)
{
	SYPoiCategoryUnknown,
	SYPoiCategoryRent_a_Car_Facility,
	SYPoiCategoryTourist_Information_Office,
	SYPoiCategoryMuseum,
	SYPoiCategoryTheatre,
	SYPoiCategoryCultural_Centre,
	SYPoiCategorySports_Centre,
	SYPoiCategoryHospital_Polyclinic,
	SYPoiCategoryPolice_Station,
	SYPoiCategoryCity_Hall,
	SYPoiCategoryPost_Office,
	SYPoiCategoryFirst_Aid_Post,
	SYPoiCategoryPharmacy,
	SYPoiCategoryDepartment_Store,
	SYPoiCategoryBank,
	SYPoiCategoryTravel_Agency,
	SYPoiCategoryPublic_Phone,
	SYPoiCategoryWarehouse,
	SYPoiCategorySki_Lift_Station,
	SYPoiCategoryZoo,
	SYPoiCategoryScenic_Panoramic_View,
	SYPoiCategoryTransport_Company,
	SYPoiCategoryCasino,
	SYPoiCategoryCinema,
	SYPoiCategoryWinery,
	SYPoiCategoryCargo_Centre,
	SYPoiCategoryCar_Shipping_Terminal,
	SYPoiCategoryCamping_Ground,
	SYPoiCategoryCaravan_Site,
	SYPoiCategoryCoach_and_Lorry_Parking,
	SYPoiCategoryCommunity_Centre,
	SYPoiCategoryCustoms,
	SYPoiCategoryEmbassy,
	SYPoiCategoryFrontier_Crossing,
	SYPoiCategoryMotoring_Organization_Office,
	SYPoiCategoryRecreation_Facility,
	SYPoiCategoryRoad_Side_Diner,
	SYPoiCategorySchool,
	SYPoiCategoryShopping_Centre,
	SYPoiCategoryStadium,
	SYPoiCategoryToll,
	SYPoiCategoryCollege_University,
	SYPoiCategoryBusiness_Facility,
	SYPoiCategoryAirport,
	SYPoiCategoryBus_Station,
	SYPoiCategoryExhibition_Centre,
	SYPoiCategoryKindergarten,
	SYPoiCategoryEmergency_Call_Station,
	SYPoiCategoryEmergency_Medical_Service,
	SYPoiCategoryFire_Brigade,
	SYPoiCategoryFreeport,
	SYPoiCategoryCompany,
	SYPoiCategoryATM,
	SYPoiCategoryHippodrome,
	SYPoiCategoryBeach,
	SYPoiCategoryRestaurant_Area,
	SYPoiCategoryIce_Skating_Rink,
	SYPoiCategoryCourthouse,
	SYPoiCategoryMountain_Peak,
	SYPoiCategoryOpera,
	SYPoiCategoryConcert_Hall,
	SYPoiCategoryBovag_Garage,
	SYPoiCategoryTennis_Court,
	SYPoiCategorySkating_Rink,
	SYPoiCategoryWater_Sport,
	SYPoiCategoryMusic_Centre,
	SYPoiCategoryDoctor,
	SYPoiCategoryDentist,
	SYPoiCategoryVeterinarian,
	SYPoiCategoryCafe_Pub,
	SYPoiCategoryConvention_Centre,
	SYPoiCategoryLeisure_Centre,
	SYPoiCategoryNightlife,
	SYPoiCategoryYacht_Basin,
	SYPoiCategoryCondominium,
	SYPoiCategoryCommercial_Building,
	SYPoiCategoryIndustrial_Building,
	SYPoiCategoryNatives_Reservation,
	SYPoiCategoryCemetery,
	SYPoiCategoryGeneral,
	SYPoiCategoryBreakdown_Service,
	SYPoiCategoryVehicle_Equipment_Provider,
	SYPoiCategoryEntertainment,
	SYPoiCategoryAbbey,
	SYPoiCategoryAmusement_Park,
	SYPoiCategoryArts_Centre,
	SYPoiCategoryBuilding_Footprint,
	SYPoiCategoryCastle,
	SYPoiCategoryChurch,
	SYPoiCategoryFactory_Ground_Philips,
	SYPoiCategoryFortress,
	SYPoiCategoryGolf_Course,
	SYPoiCategoryHoliday_Area,
	SYPoiCategoryLibrary,
	SYPoiCategoryLighthouse,
	SYPoiCategoryMilitary_Cemetery,
	SYPoiCategoryMonastery,
	SYPoiCategoryMonument,
	SYPoiCategoryNatural_Reserve,
	SYPoiCategoryPrison,
	SYPoiCategoryRocks,
	SYPoiCategorySports_Hall,
	SYPoiCategoryState_Police_Office,
	SYPoiCategoryWalking_Area,
	SYPoiCategoryWater_Mill,
	SYPoiCategoryWindmill,
	SYPoiCategoryRent_a_Car_Parking,
	SYPoiCategoryCar_Racetrack,
	SYPoiCategoryMountain_Pass,
	SYPoiCategorySwimming_Pool,
	SYPoiCategoryGovernment_Office,
	SYPoiCategoryAgricultural_Industry,
	SYPoiCategoryConstruction,
	SYPoiCategoryFactories,
	SYPoiCategoryMedia,
	SYPoiCategoryMedical_Material,
	SYPoiCategoryPersonal_Services,
	SYPoiCategoryProfessionals,
	SYPoiCategoryReal_Estate,
	SYPoiCategoryServices,
	SYPoiCategoryBorder_Point,
	SYPoiCategoryHair_And_Beauty,
	SYPoiCategoryGroceries,
	SYPoiCategoryPort,
	SYPoiCategoryExchange,
	SYPoiCategoryMoney_Transfer,
	SYPoiCategoryPastry_and_Sweets,
	SYPoiCategoryArcheology,
	SYPoiCategoryEcotourism_Sites,
	SYPoiCategoryHunting_Shop,
	SYPoiCategoryKids_Place,
	SYPoiCategoryMobile_Shop,
	SYPoiCategoryMosque,
	SYPoiCategorySquares,
	SYPoiCategoryLocal_Names,
	SYPoiCategoryTrafficLights,
	SYPoiCategoryParking_Garage,
	SYPoiCategoryPlace_of_Worship,
	SYPoiCategoryFerry_Terminal,
	SYPoiCategoryAirline_Access,
	SYPoiCategoryOpen_Parking_Area,
	SYPoiCategoryImportant_Tourist_Attraction,
	SYPoiCategoryRailway_Station,
	SYPoiCategoryRest_Area,
	SYPoiCategoryShop,
	SYPoiCategoryPark_and_Recreation_Area,
	SYPoiCategoryForest_Area,
	SYPoiCategoryMilitary_Installation,
	SYPoiCategoryPublic_Transport_Stop,
	SYPoiCategoryPark_And_Ride,
	SYPoiCategoryWikipedia,
	SYPoiCategoryCar_Repair_Facility,
	SYPoiCategoryPetrol_Station,
	SYPoiCategoryHotel_or_Motel,
	SYPoiCategoryRestaurant,
	SYPoiCategoryCash_Dispenser,
	SYPoiCategoryCar_Dealer,
	SYPoiCategoryFood,
	SYPoiCategorySpeed_Cameras,
	SYPoiCategorySupermarket,
	SYPoiCategoryCar_Services,
	SYPoiCategoryAccessories_Furniture,
	SYPoiCategoryBooks_Cards,
	SYPoiCategoryChildrens_Fashion,
	SYPoiCategoryChildren_Toys,
	SYPoiCategoryCosmetics_Perfumes,
	SYPoiCategoryElectronics_Mobiles,
	SYPoiCategoryFashion_Mixed,
	SYPoiCategoryFashion_Accessories,
	SYPoiCategoryTraditional_Fashion,
	SYPoiCategoryGifts_Antiques,
	SYPoiCategoryJewellery_Watches,
	SYPoiCategoryLadies_Fashion,
	SYPoiCategoryLifestyle_Fitness,
	SYPoiCategoryMen_s_Fashion,
	SYPoiCategoryOpticians_Sunglasses,
	SYPoiCategoryShoes_Bags,
	SYPoiCategorySports,
	SYPoiCategoryMetro,
	SYPoiCategoryChevrolet_Car_Dealer,
	SYPoiCategoryChevrolet_Car_Repair
};

/*!
 @brief Available POI Groups.
 */
typedef NS_ENUM(NSInteger, SYPoiGroup)
{
	SYPoiGroupUnknown,
	SYPoiGroupFood_and_Drink,
	SYPoiGroupAccommodation,
	SYPoiGroupShopping,
	SYPoiGroupTransportation,
	SYPoiGroupTourism,
	SYPoiGroupSocial_Life,
	SYPoiGroupServices_and_Education,
	SYPoiGroupSport,
	SYPoiGroupVehicle_Services,
	SYPoiGroupEmergency,
	SYPoiGroupGuides,
	SYPoiGroupParking,
	SYPoiGroupPetrol_Station,
	SYPoiGroupBankATM
};

/*!
 @brief Contains information about selected POI.
 */
@interface SYPoiInfo : NSObject
/*!
 @brief Geographical location of the POI.
 */
@property(nonatomic,readonly,nonnull) SYGeoCoordinate* coordinate;
/*!
 @brief Represents the POI name. For example: Sydney opera house, Statue of Liberty.
 */
@property(nonatomic,readonly,nonnull) NSString* name;
/*!
 @brief POI parent group.
 */
@property(nonatomic,readonly) SYPoiGroup group;
/*!
 @brief POI category.
 */
@property(nonatomic,readonly) SYPoiCategory category;
@end

/*!
 @brief Visually represents a selectable point of interest inside a view.
 SYPoiObject is a proxy object (created by the SDK) and its instances cannot be modified. They can be selected from within their containing view (MapView) and can be used to obtain information about the real-world point of interest that they represent.
 */
@interface SYPoiObject : SYProxyObject
@end

/*!
 @brief Represents a selectable city inside a view.
 */
@interface SYCityObject : SYProxyObject
@end

/*!
 @brief Represents a selectable radar object inside a view.
 */
@interface SYRadarObject : SYProxyObject
@property(nonatomic,readonly) NSInteger radarId;
@property(nonatomic,readonly) SYRadarType radarType;
@end

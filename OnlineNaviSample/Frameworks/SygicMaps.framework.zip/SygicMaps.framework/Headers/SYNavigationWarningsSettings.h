#import <SygicMaps/SYTypes.h>

/*!
 @brief Enables to change some POIs settings.
 */
@interface SYPoisSettings : NSObject

/*!
 @brief Set the maximal searched distance from vehicle.
 */
@property(nonatomic,assign) SYDistance maxDistance;

/*!
 @brief Set POI categories, which should be  searched.
 */
@property(nonatomic,copy, nonnull) NSArray<NSNumber*>* categories;
@end

/*!
 @brief Enables to change some POI on route settings.
 */
@interface SYPoiOnRouteSettings : NSObject
/*!
 @brief Set the maximal number of search POIs.
 */
@property(nonatomic,assign) NSUInteger maxCount;

/*!
 @brief Set the maximal searched distance by POI on route.
 */
@property(nonatomic,assign) SYDistance maxDistance;

/*!
 @brief Set POI categories, which should be shown on POI on route.
 */
@property(nonatomic,copy, nonnull) NSArray<NSNumber*>* categories;
@end

/*!
 @brief Enables to change some direction settings.
 */
@interface SYDirectionSettings : NSObject
/*!
 @brief Set the minimum distance between first end second instruction to be notified as one.
 */
@property(nonatomic,assign) NSUInteger nextDirectionDistance;
@end

/*!
 @brief Enables to change some Speed limit settings.
 */
@interface SYSpeedLimitWarningSettings : NSObject
/*!
 @brief Set diff speed above maximum allowed speed to be notified as speeding in city.
 */
@property(nonatomic,assign) SYSpeed speedLimitDiffInCity;

/*!
 @brief Set diff speed above maximum allowed speed to be notified as speeding.
 */
@property(nonatomic,assign) SYSpeed speedLimitDiff;

/*!
 @brief Set next speed limit search distance ahead vehicle.
 */
@property(nonatomic,assign) SYDistance nextSpeedLimitDistance;

/*!
 @brief Set distance how far will look for other speed limit ahead vehicle in city.
 */
@property(nonatomic,assign) SYDistance nextSpeedLimitDistanceInCity;
@end

/*!
 @brief Enables to change some Speed camera settings.
 */
@interface SYSpeedCameraWarningSettings : NSObject
/*!
 @brief Set Speed cameras search distance ahead vehicle in city.
 */
@property(nonatomic,assign) SYDistance searchDistanceInCity;

/*!
 @brief Set Speed cameras search distance ahead vehicle.
 */
@property(nonatomic,assign) SYDistance searchDistance;
@end

/*!
 @brief Enables to change some Railway crossing settings.
 */
@interface SYRailwayCrossingWarningSettings : NSObject
/*!
 @brief Set Railway crossing search distance ahead vehicle.
 */
@property(nonatomic,assign) SYDistance searchDistance;
@end

/*!
 @brief Base class for warning notification settings. To access these settings you have to use [SYNavigation sharedNavigation] instance.
 */
@interface SYWarningSettings : NSObject
/*!
 @brief Poi on route Warning settings.
 */
@property(nonatomic,readonly,nonnull) SYPoiOnRouteSettings* poiOnRoute;
/*!
 @brief Pois Warning settings.
 */
@property(nonatomic,readonly,nonnull) SYPoisSettings* pois;
/*!
 @brief Direction Warning settings.
 */
@property(nonatomic,readonly,nonnull) SYDirectionSettings* direction;
/*!
 @brief Speed limit Warning settings.
 */
@property(nonatomic,readonly,nonnull) SYSpeedLimitWarningSettings* speedLimit;
/*!
 @brief Speed camera Warning settings.
 */
@property(nonatomic,readonly,nonnull) SYSpeedCameraWarningSettings* speedCamera;
/*!
 @brief Railway crossing Warning settings.
 */
@property(nonatomic,readonly,nonnull) SYRailwayCrossingWarningSettings* railwayCrossing;

/*!
 @brief Reset all settings to default
 */
-(void)resetToDefault;

@end


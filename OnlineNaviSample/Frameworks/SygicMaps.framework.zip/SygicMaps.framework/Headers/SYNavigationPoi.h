#import <SygicMaps/SYTypes.h>
#import <SygicMaps/SYNavigationWarnings.h>

@class SYPoiInfo;

/*!
 @brief Provides warning notifications about POIs on the current route.
 */
@interface SYPoiOnRoute : SYWarning
/*!
 @brief Information about the selected POI on the route.
 */
@property(nonatomic,readonly,nonnull) SYPoiInfo* poiInfo;
/*!
 @brief Unique identifier for current SYPoiOnRoute objects set.
 Can be used to match repeating SYPoiOnRoute warnings received in [SYNavigationDelegate navigation:didUpdatePoisOnRoute:] method.
 */
@property(nonatomic,readonly) NSUInteger uuid;
@end

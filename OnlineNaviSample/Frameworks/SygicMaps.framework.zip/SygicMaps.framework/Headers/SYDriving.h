#import <SygicMaps/SYTypes.h>

@class SYDriving, SYPosition;

@interface SYDrivingEvent : NSObject
@property(nonatomic,readonly,nonnull) SYPosition* position;
@end

@interface SYDrivingFastCornering : SYDrivingEvent
@property(nonatomic,readonly) SYSpeed speedOverSafeLimit;
@property(nonatomic,readonly) SYLength corneringRadius;
@end

@interface SYDrivingSpeeding : SYDrivingEvent
@property(nonatomic,readonly) SYSpeed currentSpeed;
@property(nonatomic,readonly) SYSpeed speedRestriction;
@end

@interface SYDrivingHardAccelerating : SYDrivingEvent
@property(nonatomic,readonly) SYSpeed speedChange;
@end

@interface SYDrivingHardBraking : SYDrivingEvent
@property(nonatomic,readonly) SYSpeed speedChange;
@end

@protocol SYDrivingDelegate <NSObject>
@optional
-(void)driving:(nonnull SYDriving*)driving didDetectFastCornering:(nonnull SYDrivingFastCornering*)fastCornering;
-(void)driving:(nonnull SYDriving*)driving didDetectSpeeding:(nonnull SYDrivingSpeeding*)speeding;
-(void)driving:(nonnull SYDriving*)driving didDetectHardBraking:(nonnull SYDrivingHardBraking*)braking;
-(void)driving:(nonnull SYDriving*)driving didDetectHardAccelerating:(nonnull SYDrivingHardAccelerating*)accelerating;
@end

@interface SYDriving : NSObject
@property(nonatomic,weak,nullable) id<SYDrivingDelegate> delegate;
@end
